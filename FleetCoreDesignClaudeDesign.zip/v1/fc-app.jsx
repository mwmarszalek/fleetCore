// fc-app.jsx — Main App
const { useState, useEffect, useRef, useCallback } = React;

// ── Clock ─────────────────────────────────────────────────
function Clock() {
  const [t, setT] = useState(new Date());
  useEffect(() => { const id = setInterval(()=>setT(new Date()),1000); return ()=>clearInterval(id); }, []);
  const pad = n => String(n).padStart(2,'0');
  return <span className="header-time">{pad(t.getHours())}:{pad(t.getMinutes())}:{pad(t.getSeconds())}</span>;
}

// ── LineBadge ─────────────────────────────────────────────
function LineBadge({ line, small }) {
  const depot = LINES_DATA.find(l=>l.id===line)?.depot || 'SPAK';
  const col = DEPOTS_DATA[depot].color;
  const size = small ? {width:28,height:17,fontSize:10} : {width:36,height:22,fontSize:11};
  return (
    <div className="line-badge" style={{...size, background:col+'18', color:col, border:`1px solid ${col}44`}}>
      {line}
    </div>
  );
}

// ── Sidebar ───────────────────────────────────────────────
function Sidebar({ myLines, vehicles, dispatchers, selectedLine, onSelectLine, onTakeLine, onReleaseLine, activeTab }) {
  const [filter, setFilter] = useState('');
  const [depotFilter, setDepotFilter] = useState('ALL');
  const [collapsed, setCollapsed] = useState({my:false, avail:true, others:true});

  const allControlled = new Set([
    ...myLines,
    ...dispatchers.flatMap(d=>d.lines),
  ]);

  const controllerOf = line => dispatchers.find(d=>d.lines.includes(line));

  function vehicleCount(line) { return vehicles.filter(v=>v.line===line).length; }

  function delayDots(line) {
    const vs = vehicles.filter(v=>v.line===line);
    return vs.map(v => ({color: delayColor(v.delay), id: v.id}));
  }

  const filtered = id => {
    if (filter && !id.toLowerCase().includes(filter.toLowerCase())) return false;
    if (depotFilter !== 'ALL') {
      const d = LINES_DATA.find(l=>l.id===id)?.depot;
      if (d !== depotFilter) return false;
    }
    return true;
  };

  const DEPOT_ORDER = ['SPAK','SPAD','SPPK','PKS','TRAM'];

  const myArr = [...myLines].filter(filtered);
  const availArr = LINES_DATA.map(l=>l.id).filter(id=>!allControlled.has(id)&&filtered(id));
  const othersArr = LINES_DATA.map(l=>l.id).filter(id=>!myLines.has(id)&&controllerOf(id)&&filtered(id));

  // Group an array of line IDs by depot
  function byDepot(ids) {
    const groups = {};
    DEPOT_ORDER.forEach(d => { groups[d] = []; });
    ids.forEach(id => {
      const d = LINES_DATA.find(l=>l.id===id)?.depot || 'SPAK';
      if (groups[d]) groups[d].push(id);
    });
    return DEPOT_ORDER.filter(d=>groups[d].length>0).map(d=>({depot:d, lines:groups[d]}));
  }

  function Section({ title, count, isOpen, onToggle, children, accent }) {
    return (
      <div className="sidebar-section">
        <div className="sidebar-section-header" onClick={onToggle} style={{cursor:'pointer'}}>
          <div className="section-toggle">
            <span style={{transform:isOpen?'rotate(0)':'rotate(-90deg)',transition:'transform 0.2s',fontSize:8,color:'var(--text-dim)',display:'inline-block'}}>▼</span>
            <span className="sidebar-section-title" style={accent?{color:accent}:{}}>{title}</span>
          </div>
          <span className="sidebar-section-count">{count}</span>
        </div>
        {isOpen && children}
      </div>
    );
  }

  function DepotGroup({ depot, lines, renderLine }) {
    const col = DEPOTS_DATA[depot].color;
    const [open, setOpen] = useState(true);
    return (
      <div>
        <div onClick={()=>setOpen(o=>!o)} style={{
          display:'flex',alignItems:'center',gap:6,padding:'4px 12px 3px',
          cursor:'pointer',userSelect:'none',
        }}>
          <div style={{width:3,height:12,borderRadius:2,background:col,flexShrink:0}}></div>
          <span style={{fontSize:10,fontWeight:600,color:col,letterSpacing:'0.06em',textTransform:'uppercase'}}>{DEPOTS_DATA[depot].label}</span>
          <span style={{fontFamily:'var(--mono)',fontSize:9,color:'var(--text-dim)',marginLeft:2}}>{lines.length}</span>
          <span style={{fontSize:8,color:'var(--text-dim)',marginLeft:'auto',transform:open?'none':'rotate(-90deg)',transition:'transform 0.15s'}}>▼</span>
        </div>
        {open && lines.map(id => renderLine(id))}
      </div>
    );
  }

  // Konwencja: ujemny = opóźniony (czerwony), dodatni = przyspieszony (niebieski)
  function vehicleChipColor(delay) {
    if (delay < -8)  return { bg:'rgba(248,81,73,0.22)',  border:'rgba(248,81,73,0.6)',  text:'#f85149' };
    if (delay < -3)  return { bg:'rgba(248,81,73,0.12)',  border:'rgba(248,81,73,0.35)', text:'#f87171' };
    if (delay <= 0)  return { bg:'rgba(125,133,144,0.12)', border:'rgba(125,133,144,0.3)', text:'#8b949e' };
    if (delay <= 2)  return { bg:'rgba(88,166,255,0.10)', border:'rgba(88,166,255,0.3)', text:'#79b8ff' };
    return               { bg:'rgba(88,166,255,0.20)',  border:'rgba(88,166,255,0.55)', text:'#58a6ff' };
  }

  function delayChipLabel(d) {
    if (d === 0) return '0';
    return d < 0 ? `${d}` : `+${d}`;
  }

  function LineRowMy({ id }) {
    const vs = [...vehicles.filter(v=>v.line===id)].sort((a,b)=>a.delay-b.delay); // najbardziej opóźniony (najbar. ujemny) pierwszy
    return (
      <div className={`line-row ${selectedLine===id?'active':''}`}
        style={{flexDirection:'column',alignItems:'flex-start',gap:4,paddingBottom:6}}
        onClick={()=>onSelectLine(id)}>
        <div style={{display:'flex',alignItems:'center',width:'100%',gap:6}}>
          <LineBadge line={id} small/>
          <span style={{fontSize:12,fontWeight:500,color:'var(--text)',flex:1}}>{id}</span>
          <span style={{fontFamily:'var(--mono)',fontSize:10,color:'var(--text-dim)'}}>{vs.length}×</span>
          <button className="release-btn" onClick={e=>{e.stopPropagation();onReleaseLine(id);}}>Zwolnij</button>
        </div>
        {vs.length > 0 && (
          <div style={{display:'flex',flexWrap:'wrap',gap:3,paddingLeft:2,width:'100%'}}>
            {vs.map(v => {
              const c = vehicleChipColor(v.delay);
              return (
                <div key={v.id}
                  onClick={e=>{e.stopPropagation();onSelectLine(id);}}
                  title={`${v.brigade} → ${v.direction}`}
                  style={{
                    display:'flex',alignItems:'center',gap:3,
                    padding:'1px 5px',borderRadius:3,
                    background:c.bg, border:`1px solid ${c.border}`,
                    fontFamily:'var(--mono)',fontSize:10,cursor:'default',
                  }}>
                  <span style={{color:'var(--text-dim)'}}>{v.id}</span>
                  <span style={{color:c.text,fontWeight:600}}>{delayChipLabel(v.delay)}</span>
                </div>
              );
            })}
          </div>
        )}
      </div>
    );
  }

  function LineRowAvail({ id }) {
    return (
      <div key={id} className={`line-row ${selectedLine===id?'active':''}`} onClick={()=>onSelectLine(id)}>
        <LineBadge line={id} small/>
        <span className="line-name">{id}</span>
        <span style={{fontFamily:'var(--mono)',fontSize:10,color:'var(--text-dim)',marginRight:4}}>{vehicleCount(id)}×</span>
        <button className="take-btn" onClick={e=>{e.stopPropagation();onTakeLine(id);}}>Przejmij</button>
      </div>
    );
  }

  function LineRowOther({ id }) {
    const ctrl = controllerOf(id);
    return (
      <div key={id} className={`line-row ${selectedLine===id?'active':''}`} onClick={()=>onSelectLine(id)}>
        <LineBadge line={id} small/>
        <div style={{flex:1,minWidth:0}}>
          <span style={{fontSize:12,color:'var(--text-dim)'}}>{id}</span>
          <div style={{fontSize:10,color:'var(--text-off)',overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{ctrl?.name}</div>
        </div>
      </div>
    );
  }

  return (
    <div className="app-sidebar">
      <div className="sidebar-search">
        <input className="search-input" value={filter} onChange={e=>setFilter(e.target.value)} placeholder="Szukaj linii…"/>
      </div>

      <Section title="Moje linie" count={myArr.length} isOpen={!collapsed.my} onToggle={()=>setCollapsed(c=>({...c,my:!c.my}))} accent="var(--spak)">
        {myArr.length===0 && <div style={{padding:'8px 14px',fontSize:11,color:'var(--text-dim)'}}>Brak kontrolowanych linii</div>}
        {byDepot(myArr).map(({depot,lines})=>(
          <DepotGroup key={depot} depot={depot} lines={lines} renderLine={id=><LineRowMy key={id} id={id}/>}/>
        ))}
      </Section>

      <div style={{height:1,background:'var(--border)',margin:'2px 0'}}></div>

      <Section title="Dostępne linie" count={availArr.length} isOpen={!collapsed.avail} onToggle={()=>setCollapsed(c=>({...c,avail:!c.avail}))}>
        {byDepot(availArr).map(({depot,lines})=>(
          <DepotGroup key={depot} depot={depot} lines={lines} renderLine={id=><LineRowAvail key={id} id={id}/>}/>
        ))}
      </Section>

      <div style={{height:1,background:'var(--border)',margin:'2px 0'}}></div>

      <Section title="Kontrolowane przez innych" count={othersArr.length} isOpen={!collapsed.others} onToggle={()=>setCollapsed(c=>({...c,others:!c.others}))}>
        {byDepot(othersArr).map(({depot,lines})=>(
          <DepotGroup key={depot} depot={depot} lines={lines} renderLine={id=><LineRowOther key={id} id={id}/>}/>
        ))}
      </Section>
    </div>
  );
}

// ── MapView ───────────────────────────────────────────────
function MapView({ vehicles, myLines, selectedLine, selectedVehicle, onSelectVehicle, showAllRoutes }) {
  const containerRef = useRef(null);
  const mapRef = useRef(null);
  const routeLayersRef = useRef({});
  const markerLayersRef = useRef({});
  const tooltipRef = useRef(null);
  const [tooltip, setTooltip] = useState(null); // {vehicle, x, y}

  // Init map
  useEffect(() => {
    if (mapRef.current) return;
    const map = L.map(containerRef.current, {
      center: [53.4285, 14.5528], zoom: 13,
      zoomControl: false, attributionControl: false,
    });
    L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 19,
    }).addTo(map);
    // Dark map via CSS invert
    const style = document.createElement('style');
    style.textContent = '.leaflet-tile-pane { filter: invert(1) hue-rotate(180deg) brightness(0.9) contrast(0.85) saturate(0.6); }';
    document.head.appendChild(style);
    L.control.zoom({ position: 'bottomright' }).addTo(map);
    mapRef.current = map;
    return () => { map.remove(); mapRef.current = null; };
  }, []);

  // Update routes
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;
    // Clear old route layers
    Object.values(routeLayersRef.current).forEach(l => map.removeLayer(l));
    routeLayersRef.current = {};

    const linesToShow = showAllRoutes
      ? Object.keys(ROUTE_PATHS)
      : [...myLines, ...(selectedLine ? [selectedLine] : [])];

    linesToShow.forEach(lineId => {
      const path = ROUTE_PATHS[lineId];
      if (!path) return;
      const depot = LINES_DATA.find(l=>l.id===lineId)?.depot || 'SPAK';
      const col = DEPOTS_DATA[depot].color;
      const isSelected = lineId === selectedLine;
      const isMine = myLines.has(lineId);
      const layer = L.polyline(path, {
        color: col,
        weight: isSelected ? 5 : isMine ? 3 : 1.5,
        opacity: isSelected ? 1 : isMine ? 0.7 : 0.3,
        dashArray: isMine || isSelected ? null : '4 4',
      }).addTo(map);
      routeLayersRef.current[lineId] = layer;
    });
  }, [myLines, selectedLine, showAllRoutes]);

  // Update vehicle markers
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;
    Object.values(markerLayersRef.current).forEach(m => map.removeLayer(m));
    markerLayersRef.current = {};

    const visibleVehicles = vehicles.filter(v =>
      myLines.has(v.line) || v.line === selectedLine
    );

    visibleVehicles.forEach(v => {
      const depot = DEPOTS_DATA[v.depot];
      const col = depot.color;
      const dc = v.delay > 2 ? '#f85149' : v.delay < -1 ? '#58a6ff' : '#3fb950';
      const isSelected = selectedVehicle?.id === v.id;

      const icon = L.divIcon({
        html: `<div class="vm" style="border-color:${col};${isSelected?'transform:scale(1.15);box-shadow:0 0 0 2px '+col+',0 4px 12px rgba(0,0,0,0.6)':''}" data-vid="${v.id}">
          <div class="vm-dot" style="background:${dc}"></div>
          <span class="vm-line" style="color:${col}">${v.line}</span>
          <span class="vm-id">${v.id}</span>
        </div>`,
        className: '',
        iconSize: [62, 26],
        iconAnchor: [31, 13],
      });

      const marker = L.marker([v.lat, v.lng], { icon })
        .addTo(map)
        .on('click', () => onSelectVehicle(v))
        .on('mouseover', (e) => {
          const pt = map.latLngToContainerPoint([v.lat, v.lng]);
          setTooltip({ vehicle: v, x: pt.x, y: pt.y });
        })
        .on('mouseout', () => setTooltip(null));

      markerLayersRef.current[v.id] = marker;
    });
  }, [vehicles, myLines, selectedLine, selectedVehicle]);

  return (
    <div style={{position:'relative',width:'100%',height:'100%'}}>
      <div ref={containerRef} id="leaflet-map" style={{width:'100%',height:'100%'}}></div>

      {tooltip && (
        <VehicleTooltipOverlay
          vehicle={tooltip.vehicle}
          x={tooltip.x} y={tooltip.y}
          onClose={()=>setTooltip(null)}
          onSelect={()=>{ onSelectVehicle(tooltip.vehicle); setTooltip(null); }}
        />
      )}
    </div>
  );
}

// ── VehicleTooltipOverlay ─────────────────────────────────
function VehicleTooltipOverlay({ vehicle, x, y, onClose, onSelect }) {
  const col = DEPOTS_DATA[vehicle.depot].color;
  const dc = delayColor(vehicle.delay);
  const style = {
    position:'absolute', left: Math.min(x+10, window.innerWidth-220), top: Math.max(y-120, 10),
    zIndex:500, pointerEvents:'none',
  };
  return (
    <div className="vtip" style={style}>
      <div className="vtip-header">
        <div className="vtip-line" style={{background:col+'22',color:col,border:`1px solid ${col}55`}}>{vehicle.line}</div>
        <div>
          <div className="vtip-brig">{vehicle.brigade}</div>
          <div style={{fontFamily:'var(--mono)',fontSize:10,color:'var(--text-dim)'}}>{vehicle.depot}</div>
        </div>
      </div>
      <div className="vtip-dir">→ {vehicle.direction}</div>
      {[['Pojazd',vehicle.id],['Prędkość',`${vehicle.speed} km/h`],['Opóźnienie', <span style={{color:dc,fontWeight:600}}>{delayLabel(vehicle.delay)}</span>]].map(([k,v])=>(
        <div key={k} className="vtip-row"><span>{k}</span><span className="vtip-val">{v}</span></div>
      ))}
    </div>
  );
}

// ── BrigadesTab ───────────────────────────────────────────
function BrigadesTab({ vehicles, myLines }) {
  const [search, setSearch] = useState('');
  const vs = vehicles.filter(v =>
    myLines.has(v.line) &&
    (!search || v.id.includes(search) || v.brigade.includes(search) || v.line.includes(search))
  );
  return (
    <div style={{flex:1,overflow:'auto',padding:16}}>
      <div style={{marginBottom:12,display:'flex',gap:8,alignItems:'center'}}>
        <input className="search-input" style={{maxWidth:240}} value={search} onChange={e=>setSearch(e.target.value)} placeholder="Szukaj pojazdu / brygady…"/>
        <span style={{fontSize:11,color:'var(--text-dim)',fontFamily:'var(--mono)'}}>{vs.length} pojazdów</span>
      </div>
      <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fill,minmax(240px,1fr))',gap:8}}>
        {vs.map(v=>{
          const col = DEPOTS_DATA[v.depot].color;
          const dc = delayColor(v.delay);
          return (
            <div key={v.id} style={{background:'var(--surf)',border:'1px solid var(--border)',borderRadius:8,padding:'10px 12px',borderLeft:`3px solid ${col}`}}>
              <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:6}}>
                <div style={{width:32,height:20,borderRadius:3,background:col+'22',color:col,border:`1px solid ${col}44`,display:'flex',alignItems:'center',justifyContent:'center',fontFamily:'var(--mono)',fontSize:11,fontWeight:600}}>{v.line}</div>
                <span style={{fontFamily:'var(--mono)',fontSize:13,fontWeight:500}}>{v.brigade}</span>
                <span style={{fontFamily:'var(--mono)',fontSize:10,color:'var(--text-dim)',marginLeft:'auto'}}>{v.id}</span>
              </div>
              <div style={{fontSize:11,color:'var(--text-dim)',marginBottom:4}}>→ {v.direction}</div>
              <div style={{display:'flex',gap:12,fontSize:11}}>
                <span style={{color:'var(--text-dim)'}}>Zajezdnia: <span style={{color:col,fontWeight:500}}>{v.depot}</span></span>
                <span style={{color:dc,fontFamily:'var(--mono)',fontWeight:600,marginLeft:'auto'}}>{delayLabel(v.delay)}</span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ── App ───────────────────────────────────────────────────
function App() {
  const [myLines, setMyLines] = useState(new Set(['75','74']));
  const [vehicles, setVehicles] = useState(VEHICLES_DATA);
  const [selectedLine, setSelectedLine] = useState(null);
  const [selectedVehicle, setSelectedVehicle] = useState(null);
  const [activeTab, setActiveTab] = useState('map');
  const [activeModal, setActiveModal] = useState(null);
  const [modalVehicle, setModalVehicle] = useState(null);
  const [rightPanelMode, setRightPanelMode] = useState(null); // null | 'vehicle' | 'punct'
  const [showAllRoutes, setShowAllRoutes] = useState(false);

  // Simulate live delay changes
  useEffect(() => {
    const id = setInterval(() => {
      setVehicles(vs => vs.map(v => ({
        ...v,
        delay: Math.max(-5, Math.min(20, v.delay + (Math.random() > 0.7 ? (Math.random()>0.5?1:-1) : 0))),
        speed: Math.max(0, Math.min(80, v.speed + (Math.random()-0.5)*4)),
      })));
    }, 4000);
    return () => clearInterval(id);
  }, []);

  function takeLine(id) { setMyLines(s => new Set([...s, id])); }
  function releaseLine(id) { setMyLines(s => { const n=new Set(s); n.delete(id); return n; }); }

  function openContact(v) { setModalVehicle(v); setActiveModal('contact'); }
  function openStops(v) { setModalVehicle(v); setActiveModal('stops'); }
  function openDetour(v) { setModalVehicle(v); setActiveModal('detour'); }

  function selectVehicle(v) {
    setSelectedVehicle(v);
    setRightPanelMode('vehicle');
    setSelectedLine(v.line);
  }

  const myVehicles = vehicles.filter(v=>myLines.has(v.line));
  const delayedCount = myVehicles.filter(v=>v.delay<-2).length;
  const onTimeCount  = myVehicles.filter(v=>v.delay>=-2&&v.delay<=1).length;
  const earlyCount   = myVehicles.filter(v=>v.delay>1).length;

  return (
    <div className="app">
      {/* HEADER */}
      <header className="app-header">
        <div className="logo">
          <div className="logo-dot"></div>
          FleetCore
        </div>
        <div className="header-sep"></div>
        <span className="header-city">Centrala Ruchu ZDiTM</span>
        <div className="header-sep"></div>
        <div className="header-tabs">
          {[['map','🗺 Mapa'],['punctuality','📊 Punktualność'],['brigades','🚌 Brygady']].map(([k,l])=>(
            <button key={k} className={`header-tab ${activeTab===k?'active':''}`} onClick={()=>setActiveTab(k)}>{l}</button>
          ))}
        </div>
        <div style={{marginLeft:'auto',display:'flex',alignItems:'center',gap:8}}>
          <button className="map-btn" title="Logowanie pojazdu" onClick={()=>setActiveModal('login')} style={{width:'auto',padding:'0 10px',fontSize:11,gap:4,display:'flex',alignItems:'center'}}>
            Logowanie Pojazdów
          </button>
          <div className="notif-btn" title={`${delayedCount} opóźnień`}>
            <svg width="13" height="13" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>
            {delayedCount>0 && <div className="notif-badge"></div>}
          </div>
          <Clock/>
          <div className="header-sep"></div>
          <div className="header-user">
            <div className="header-avatar">MM</div>
            <span style={{fontSize:12}}>Michał Marszałek</span>
          </div>
        </div>
      </header>

      {/* SIDEBAR */}
      <Sidebar
        myLines={myLines} vehicles={vehicles}
        dispatchers={DISPATCHERS_DATA}
        selectedLine={selectedLine}
        onSelectLine={id=>{setSelectedLine(s=>s===id?null:id); setRightPanelMode(null);}}
        onTakeLine={takeLine} onReleaseLine={releaseLine}
        activeTab={activeTab}
      />

      {/* MAIN */}
      <div className="app-main">
        {activeTab === 'map' && (
          <>
            <MapView
              vehicles={vehicles} myLines={myLines}
              selectedLine={selectedLine} selectedVehicle={selectedVehicle}
              onSelectVehicle={selectVehicle}
              showAllRoutes={showAllRoutes}
            />
            {/* Map toolbar */}
            <div className="map-toolbar" style={{top:12,right:12,left:'auto'}}>
              <button className={`map-btn ${showAllRoutes?'active':''}`} title="Pokaż wszystkie trasy"
                onClick={()=>setShowAllRoutes(s=>!s)} style={{width:32,height:32,fontSize:10,padding:0}}>⊞</button>
              <button className="map-btn" title="Punktualność"
                onClick={()=>setRightPanelMode(m=>m==='punct'?null:'punct')} style={{fontSize:10}}>📊</button>
            </div>

            {/* Right panel */}
            {rightPanelMode==='punct' && (
              <PunctualityPanel myLines={myLines} vehicles={vehicles}
                onSelectVehicle={selectVehicle} onClose={()=>setRightPanelMode(null)}/>
            )}
            {rightPanelMode==='vehicle' && selectedVehicle && (
              <VehicleDetailPanel vehicle={selectedVehicle}
                onClose={()=>{setRightPanelMode(null);setSelectedVehicle(null);}}
                onContact={()=>openContact(selectedVehicle)}
                onStops={()=>openStops(selectedVehicle)}
                onDetour={()=>openDetour(selectedVehicle)}/>
            )}

            {/* Status bar */}
            <div className="status-bar">
              <div className="stat-item"><div className="stat-dot" style={{background:'var(--on-time)'}}></div>{onTimeCount} o czasie</div>
              <div className="stat-item"><div className="stat-dot" style={{background:'var(--delayed)'}}></div>{delayedCount} opóźnionych</div>
              <div className="stat-item"><div className="stat-dot" style={{background:'var(--early)'}}></div>{earlyCount} przyspieszone</div>
              <div style={{marginLeft:'auto',display:'flex',gap:12}}>
                <div className="stat-item">Moje linie: <strong style={{color:'var(--text)',marginLeft:3}}>{myLines.size}</strong></div>
                <div className="stat-item">Pojazdy: <strong style={{color:'var(--text)',marginLeft:3}}>{myVehicles.length}</strong></div>
              </div>
            </div>
          </>
        )}

        {activeTab === 'punctuality' && (
          <div style={{height:'100%',display:'flex',flexDirection:'column',overflow:'hidden'}}>
            <div style={{padding:'12px 16px',borderBottom:'1px solid var(--border)',display:'flex',alignItems:'center',gap:16}}>
              <div style={{fontSize:14,fontWeight:600}}>Punktualność pojazdów</div>
              <div style={{display:'flex',gap:8,marginLeft:'auto',fontFamily:'var(--mono)',fontSize:12}}>
                <span style={{color:'var(--on-time)'}}>{onTimeCount} o czasie</span>
                <span style={{color:'var(--delayed)'}}>{delayedCount} opóźnionych</span>
                <span style={{color:'var(--early)'}}>{earlyCount} przyspieszone</span>
              </div>
            </div>
            <div style={{flex:1,overflow:'auto',padding:16}}>
              <table style={{width:'100%',borderCollapse:'collapse',fontSize:12}}>
                <thead>
                  <tr style={{color:'var(--text-dim)',borderBottom:'1px solid var(--border)'}}>
                    {['Linia','Brygada','Pojazd','Kierunek','Zajezdnia','Prędkość','Opóźnienie'].map(h=>(
                      <th key={h} style={{textAlign:'left',padding:'6px 10px',fontSize:10,fontWeight:600,textTransform:'uppercase',letterSpacing:'0.06em'}}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {[...vehicles].filter(v=>myLines.has(v.line))
                    .sort((a,b)=>a.delay-b.delay)
                    .map(v=>{
                      const col = DEPOTS_DATA[v.depot].color;
                      const dc = delayColor(v.delay);
                      return (
                        <tr key={v.id} onClick={()=>{setActiveTab('map');selectVehicle(v);}}
                          style={{borderBottom:'1px solid var(--border)',cursor:'pointer',transition:'background 0.1s'}}
                          onMouseOver={e=>e.currentTarget.style.background='var(--surf2)'}
                          onMouseOut={e=>e.currentTarget.style.background='transparent'}>
                          <td style={{padding:'7px 10px'}}><div style={{display:'inline-flex',alignItems:'center',justifyContent:'center',width:28,height:18,borderRadius:3,background:col+'18',color:col,fontFamily:'var(--mono)',fontSize:10,fontWeight:600,border:`1px solid ${col}44`}}>{v.line}</div></td>
                          <td style={{padding:'7px 10px',fontFamily:'var(--mono)'}}>{v.brigade}</td>
                          <td style={{padding:'7px 10px',fontFamily:'var(--mono)',color:'var(--text-dim)'}}>{v.id}</td>
                          <td style={{padding:'7px 10px',color:'var(--text-dim)',maxWidth:140,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{v.direction}</td>
                          <td style={{padding:'7px 10px'}}><span style={{color:col,fontSize:11,fontWeight:500}}>{v.depot}</span></td>
                          <td style={{padding:'7px 10px',fontFamily:'var(--mono)',color:'var(--text-dim)'}}>{v.speed.toFixed(0)} km/h</td>
                          <td style={{padding:'7px 10px',fontFamily:'var(--mono)',fontWeight:600,color:dc}}>{delayLabel(v.delay)}</td>
                        </tr>
                      );
                    })}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeTab === 'brigades' && (
          <div style={{display:'flex',flexDirection:'column',height:'100%'}}>
            <div style={{padding:'12px 16px',borderBottom:'1px solid var(--border)',display:'flex',alignItems:'center',gap:12}}>
              <div style={{fontSize:14,fontWeight:600}}>Brygady i pojazdy</div>
              <button className="take-btn" style={{marginLeft:'auto'}} onClick={()=>setActiveModal('login')}>+ Zaloguj pojazd</button>
            </div>
            <BrigadesTab vehicles={vehicles} myLines={myLines}/>
          </div>
        )}
      </div>

      {/* MODALS */}
      {activeModal==='contact' && modalVehicle && (
        <ContactModal vehicle={modalVehicle} onClose={()=>setActiveModal(null)}/>
      )}
      {activeModal==='stops' && modalVehicle && (
        <StopsModal vehicle={modalVehicle} onClose={()=>setActiveModal(null)}/>
      )}
      {activeModal==='detour' && (
        <DetourModal vehicle={modalVehicle} onClose={()=>setActiveModal(null)}/>
      )}
      {activeModal==='login' && (
        <VehicleLoginModal onClose={()=>setActiveModal(null)}/>
      )}
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App/>);
