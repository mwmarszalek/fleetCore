// fc-components.jsx — Modals & Panels
const { useState, useEffect } = React;

// ── helpers ──────────────────────────────────────────────
function depotColor(depot) { return `var(--${depot === 'TRAM' ? 'tram' : depot.toLowerCase()})`; }
function delayColor(d) { return d < -2 ? 'var(--delayed)' : d > 1 ? 'var(--early)' : 'var(--on-time)'; }
function delayLabel(d) { if (d === 0) return 'o czasie'; if (d < 0) return `${d} min`; return `+${d} min`; }

// ── ContactModal ─────────────────────────────────────────
function ContactModal({ vehicle, onClose }) {
  const [msgs, setMsgs] = useState([
    { id: 1, text: 'Dzień dobry, melduję gotowość do służby.', sent: false, time: '07:14' },
    { id: 2, text: 'Przyjęto. Proszę trzymać się rozkładu.', sent: true, time: '07:15' },
  ]);
  const [draft, setDraft] = useState('');
  const col = DEPOTS_DATA[vehicle.depot].color;

  function send() {
    if (!draft.trim()) return;
    const now = new Date();
    const time = `${String(now.getHours()).padStart(2,'0')}:${String(now.getMinutes()).padStart(2,'0')}`;
    setMsgs(m => [...m, { id: Date.now(), text: draft.trim(), sent: true, time }]);
    setDraft('');
    setTimeout(() => {
      setMsgs(m => [...m, { id: Date.now()+1, text: 'Zrozumiałem, wykonuję.', sent: false, time }]);
    }, 1200);
  }

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal" onClick={e => e.stopPropagation()} style={{minWidth:400}}>
        <div style={{display:'flex',alignItems:'center',gap:10,marginBottom:4}}>
          <div style={{width:32,height:20,borderRadius:3,background:col+'22',border:`1px solid ${col}`,display:'flex',alignItems:'center',justifyContent:'center',fontFamily:'var(--mono)',fontSize:11,fontWeight:600,color:col}}>{vehicle.line}</div>
          <div className="modal-title">Kontakt z kierowcą</div>
        </div>
        <div className="modal-sub">Brygada {vehicle.brigade} · Pojazd {vehicle.id} · {vehicle.depot}</div>
        <div style={{background:'var(--surf2)',borderRadius:8,padding:10,marginBottom:10,border:'1px solid var(--border)'}}>
          <div style={{display:'flex',gap:12,marginBottom:8}}>
            {[['Linia',vehicle.line],['Brygada',vehicle.brigade],['Pojazd',vehicle.id],['Kierunek',vehicle.direction]].map(([k,v])=>(
              <div key={k}>
                <div style={{fontSize:9,color:'var(--text-dim)',textTransform:'uppercase',letterSpacing:'0.06em',marginBottom:2}}>{k}</div>
                <div style={{fontFamily:'var(--mono)',fontSize:12}}>{v}</div>
              </div>
            ))}
          </div>
          <div style={{display:'flex',alignItems:'center',gap:6,fontSize:11}}>
            <div style={{width:6,height:6,borderRadius:'50%',background:'var(--on-time)',boxShadow:'0 0 4px var(--on-time)'}}></div>
            <span style={{color:'var(--text-dim)'}}>Kierowca online · {vehicle.speed} km/h</span>
          </div>
        </div>
        <div className="chat-messages">
          {msgs.map(m => (
            <div key={m.id} className={`chat-msg ${m.sent?'sent':'recv'}`}>
              {m.text}
              <div className="chat-msg-time">{m.time}</div>
            </div>
          ))}
        </div>
        <div className="chat-input-row">
          <input className="chat-input" value={draft} onChange={e=>setDraft(e.target.value)}
            onKeyDown={e=>e.key==='Enter'&&send()} placeholder="Wpisz wiadomość…"/>
          <button className="chat-send-btn" onClick={send}>Wyślij</button>
        </div>
        <div style={{display:'flex',gap:6,marginTop:10}}>
          {['Proszę przyspieszyć','Jedź ostrożnie','Wróć do zajezdni','OK'].map(t=>(
            <button key={t} className="btn-ghost" style={{fontSize:10,padding:'3px 8px'}}
              onClick={()=>{setDraft(t);}}>{t}</button>
          ))}
        </div>
        <div className="modal-footer">
          <button className="btn-ghost" onClick={onClose}>Zamknij</button>
        </div>
      </div>
    </div>
  );
}

// ── StopsModal ────────────────────────────────────────────
function StopsModal({ vehicle, onClose }) {
  const rawStops = STOPS_BY_LINE[vehicle.line] || [
    {id:'g1',name:'Przystanek Początkowy',seq:1},
    {id:'g2',name:'Ul. Centralna',seq:2},
    {id:'g3',name:'Rynek',seq:3},
    {id:'g4',name:'Dworzec PKP',seq:4},
    {id:'g5',name:'Przystanek Końcowy',seq:5},
  ];
  const [stops, setStops] = useState(rawStops.map((s,i)=>({...s,passed:i<2,skipped:false})));
  const currentIdx = stops.findIndex(s=>!s.passed&&!s.skipped);
  const col = DEPOTS_DATA[vehicle.depot].color;

  function toggleSkip(id) {
    setStops(ss => ss.map(s => s.id===id ? {...s,skipped:!s.skipped} : s));
  }

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal" onClick={e=>e.stopPropagation()} style={{minWidth:420}}>
        <div style={{display:'flex',alignItems:'center',gap:10,marginBottom:4}}>
          <div style={{width:32,height:20,borderRadius:3,background:col+'22',border:`1px solid ${col}`,display:'flex',alignItems:'center',justifyContent:'center',fontFamily:'var(--mono)',fontSize:11,fontWeight:600,color:col}}>{vehicle.line}</div>
          <div className="modal-title">Przystanki · {vehicle.brigade}</div>
        </div>
        <div className="modal-sub">Pojazd {vehicle.id} → {vehicle.direction}</div>
        <div style={{display:'flex',gap:8,marginBottom:10,padding:'6px 0',borderBottom:'1px solid var(--border)',fontSize:11,color:'var(--text-dim)'}}>
          <span style={{display:'flex',alignItems:'center',gap:4}}><span style={{width:8,height:8,borderRadius:'50%',background:'var(--text-dim)',display:'inline-block'}}></span> Minięty</span>
          <span style={{display:'flex',alignItems:'center',gap:4}}><span style={{width:8,height:8,borderRadius:'50%',background:'var(--on-time)',display:'inline-block',boxShadow:'0 0 4px var(--on-time)'}}></span> Aktualny</span>
          <span style={{display:'flex',alignItems:'center',gap:4}}><span style={{width:8,height:8,borderRadius:'50%',border:'2px solid var(--border2)',display:'inline-block'}}></span> Planowany</span>
          <span style={{marginLeft:'auto',color:'var(--delayed)'}}>⊘ pominięty</span>
        </div>
        <div style={{maxHeight:280,overflowY:'auto'}}>
          {stops.map((s,i)=>(
            <div key={s.id} className={`stop-row ${s.passed?'passed':''} ${s.skipped?'skipped':''}`}
              style={{background: i===currentIdx ? 'rgba(63,185,80,0.06)' : 'transparent'}}>
              <span className="stop-seq">{s.seq}</span>
              <div className={`stop-dot ${s.passed?'passed':''} ${i===currentIdx?'current':''}`}></div>
              <span className="stop-name" style={{color:s.skipped?'var(--text-dim)':'var(--text)'}}>{s.name}</span>
              {!s.passed && (
                <button className={s.skipped?'stop-restore-btn':'stop-skip-btn'}
                  onClick={()=>toggleSkip(s.id)}>{s.skipped?'Przywróć':'Pomiń'}</button>
              )}
            </div>
          ))}
        </div>
        <div className="modal-footer">
          <button className="btn-danger" onClick={()=>setStops(ss=>ss.map(s=>({...s,skipped:false})))}>Przywróć wszystkie</button>
          <button className="btn-ghost" onClick={onClose}>Zamknij</button>
        </div>
      </div>
    </div>
  );
}

// ── VehicleLoginModal ─────────────────────────────────────
function VehicleLoginModal({ onClose }) {
  const [vehicleId, setVehicleId] = useState('');
  const [line, setLine] = useState('75');
  const [number, setNumber] = useState('');
  const [depot, setDepot] = useState('SPAK');
  const [done, setDone] = useState(false);

  const allLines = LINES_DATA.map(l=>l.id).sort();
  const brigade = line && number ? `${line}/${number}` : '';

  function login() {
    if (!vehicleId || !line || !number) return;
    setDone(true);
    setTimeout(onClose, 1800);
  }

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal" onClick={e=>e.stopPropagation()}>
        <div className="modal-title">Logowanie pojazdu do brygady</div>
        <div className="modal-sub">Przypisz pojazd do linii i numeru brygady</div>
        {done ? (
          <div style={{textAlign:'center',padding:'24px 0',color:'var(--on-time)'}}>
            <div style={{fontSize:32,marginBottom:8}}>✓</div>
            <div style={{fontSize:14,fontWeight:600}}>Pojazd {vehicleId} zalogowany</div>
            <div style={{fontSize:12,color:'var(--text-dim)',marginTop:4}}>Brygada {brigade} · {depot}</div>
          </div>
        ) : (
          <>
            <div className="form-group">
              <label className="form-label">Numer pojazdu</label>
              <input className="form-input" placeholder="np. 1224, 10813, 456…" value={vehicleId} onChange={e=>setVehicleId(e.target.value)}/>
            </div>
            <div className="form-row">
              <div className="form-group">
                <label className="form-label">Linia</label>
                <select className="form-select" value={line} onChange={e=>setLine(e.target.value)}>
                  {allLines.map(l=><option key={l} value={l}>{l}</option>)}
                </select>
              </div>
              <div className="form-group">
                <label className="form-label">Numer brygady</label>
                <input className="form-input" placeholder="np. 5" value={number} onChange={e=>setNumber(e.target.value.replace(/\D/,''))} maxLength={2}/>
              </div>
            </div>
            <div className="form-group">
              <label className="form-label">Zajezdnia</label>
              <select className="form-select" value={depot} onChange={e=>setDepot(e.target.value)}>
                {Object.keys(DEPOTS_DATA).map(d=><option key={d} value={d}>{DEPOTS_DATA[d].label}</option>)}
              </select>
            </div>
            {brigade && (
              <div style={{background:'var(--surf2)',borderRadius:6,padding:'8px 12px',border:'1px solid var(--border)',fontFamily:'var(--mono)',fontSize:13,color:'var(--text)'}}>
                Brygada: <strong style={{color:depotColor(depot)}}>{brigade}</strong>
                {vehicleId && <span style={{color:'var(--text-dim)'}}> · Pojazd {vehicleId}</span>}
              </div>
            )}
            <div className="modal-footer">
              <button className="btn-ghost" onClick={onClose}>Anuluj</button>
              <button className="btn-primary" onClick={login} disabled={!vehicleId||!line||!number}
                style={{opacity:(!vehicleId||!line||!number)?0.4:1}}>Zaloguj pojazd</button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

// ── DetourModal ───────────────────────────────────────────
function DetourModal({ vehicle, onClose }) {
  const [scope, setScope] = useState('vehicle');
  const [reason, setReason] = useState('');
  const [saved, setSaved] = useState(false);
  const col = vehicle ? DEPOTS_DATA[vehicle.depot].color : 'var(--spak)';

  function save() {
    setSaved(true);
    setTimeout(onClose, 1600);
  }

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal" onClick={e=>e.stopPropagation()} style={{minWidth:440}}>
        <div className="modal-title">Wyznaczanie objazdu</div>
        <div className="modal-sub">{vehicle ? `Pojazd ${vehicle.id} · Brygada ${vehicle.brigade} · Linia ${vehicle.line}` : 'Nowy objazd'}</div>
        {saved ? (
          <div style={{textAlign:'center',padding:'24px 0',color:'var(--warn)'}}>
            <div style={{fontSize:32,marginBottom:8}}>⚠</div>
            <div style={{fontSize:14,fontWeight:600}}>Objazd aktywowany</div>
            <div style={{fontSize:12,color:'var(--text-dim)',marginTop:4}}>Kierowca otrzymał powiadomienie</div>
          </div>
        ) : (
          <>
            <div className="form-group">
              <label className="form-label">Zakres objazdu</label>
              <div style={{display:'flex',gap:6}}>
                {[['vehicle','Ten pojazd'],['line','Cała linia'],['direction','Jeden kierunek']].map(([v,l])=>(
                  <button key={v} className="btn-ghost" onClick={()=>setScope(v)}
                    style={{flex:1,fontSize:11,padding:'5px 6px',borderColor:scope===v?col:'var(--border2)',color:scope===v?col:'var(--text-dim)',background:scope===v?col+'11':'none'}}>
                    {l}
                  </button>
                ))}
              </div>
            </div>
            <div className="form-group">
              <label className="form-label">Przyczyna objazdu</label>
              <select className="form-select" value={reason} onChange={e=>setReason(e.target.value)}>
                <option value="">Wybierz…</option>
                <option>Wypadek drogowy</option>
                <option>Roboty drogowe</option>
                <option>Impreza masowa</option>
                <option>Awaria sieci trakcyjnej</option>
                <option>Inne utrudnienia</option>
              </select>
            </div>
            <div style={{background:'var(--surf2)',borderRadius:8,padding:12,border:'1px solid var(--border)',marginBottom:4}}>
              <div style={{fontSize:11,color:'var(--text-dim)',marginBottom:6,fontWeight:600,textTransform:'uppercase',letterSpacing:'0.06em'}}>Trasa objazdu</div>
              <div style={{height:120,background:'var(--surf3)',borderRadius:6,border:'2px dashed var(--border2)',display:'flex',alignItems:'center',justifyContent:'center',flexDirection:'column',gap:4}}>
                <div style={{fontSize:22,opacity:0.3}}>🗺</div>
                <div style={{fontSize:11,color:'var(--text-dim)'}}>Kliknij na mapie aby wyznaczyć trasę</div>
                <div style={{fontSize:10,color:'var(--text-off)'}}>Funkcja interaktywna w widoku mapy</div>
              </div>
            </div>
            <div className="modal-footer">
              <button className="btn-ghost" onClick={onClose}>Anuluj</button>
              <button className="btn-primary" onClick={save} disabled={!reason} style={{opacity:!reason?0.4:1,background:'var(--warn)',border:'none'}}>Aktywuj objazd</button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

// ── PunctualityPanel ──────────────────────────────────────
function PunctualityPanel({ myLines, vehicles, onSelectVehicle, onClose }) {
  const [sortBy, setSortBy] = useState('delay');
  const [filterLine, setFilterLine] = useState('all');

  const myVehicles = vehicles.filter(v => myLines.has(v.line));
  const lines = [...new Set(myVehicles.map(v=>v.line))].sort();

  const sorted = [...myVehicles]
    .filter(v => filterLine==='all' || v.line===filterLine)
    .sort((a,b) => sortBy==='delay' ? b.delay-a.delay : sortBy==='line' ? a.line.localeCompare(b.line) : a.brigade.localeCompare(b.brigade));

  return (
    <div className="right-panel open">
      <div className="rp-header">
        <div className="rp-title">Punktualność</div>
        <button className="rp-close" onClick={onClose}>✕</button>
      </div>
      <div style={{padding:'6px 8px',borderBottom:'1px solid var(--border)',display:'flex',gap:4,flexWrap:'wrap'}}>
        <button className={`sort-btn ${filterLine==='all'?'active':''}`} onClick={()=>setFilterLine('all')}>Wszystkie</button>
        {lines.map(l=>(
          <button key={l} className={`sort-btn ${filterLine===l?'active':''}`} onClick={()=>setFilterLine(l)}>{l}</button>
        ))}
      </div>
      <div className="punct-sort">
        {[['delay','Opóźnienie'],['line','Linia'],['brigade','Brygada']].map(([k,l])=>(
          <button key={k} className={`sort-btn ${sortBy===k?'active':''}`} onClick={()=>setSortBy(k)}>{l}</button>
        ))}
      </div>
      <div className="rp-body" style={{padding:'0 8px'}}>
        {sorted.length===0 && (
          <div style={{padding:'24px 0',textAlign:'center',color:'var(--text-dim)',fontSize:12}}>
            Brak pojazdów na wybranych liniach
          </div>
        )}
        {sorted.map((v,i)=>{
          const col = DEPOTS_DATA[v.depot].color;
          const dc = delayColor(v.delay);
          return (
            <div key={v.id} className="punct-row" onClick={()=>onSelectVehicle(v)}>
              <span className="punct-rank">{i+1}</span>
              <div className="punct-line" style={{background:col+'18',color:col}}>{v.line}</div>
              <div style={{flex:1,minWidth:0}}>
                <div className="punct-brig">{v.brigade}</div>
                <div className="punct-dir">{v.direction}</div>
              </div>
              <div style={{textAlign:'right'}}>
                <div className="punct-delay" style={{color:dc}}>{delayLabel(v.delay)}</div>
                <div style={{fontFamily:'var(--mono)',fontSize:9,color:'var(--text-dim)'}}>{v.id}</div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ── VehicleDetailPanel ────────────────────────────────────
function VehicleDetailPanel({ vehicle, onClose, onContact, onStops, onDetour }) {
  const col = DEPOTS_DATA[vehicle.depot].color;
  const dc = delayColor(vehicle.delay);

  return (
    <div className="right-panel open">
      <div className="rp-header">
        <div style={{display:'flex',alignItems:'center',gap:8}}>
          <div style={{width:32,height:20,borderRadius:3,background:col+'22',border:`1px solid ${col}`,display:'flex',alignItems:'center',justifyContent:'center',fontFamily:'var(--mono)',fontSize:11,fontWeight:600,color:col}}>{vehicle.line}</div>
          <div className="rp-title">{vehicle.brigade}</div>
        </div>
        <button className="rp-close" onClick={onClose}>✕</button>
      </div>
      <div className="rp-body">
        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:8,marginBottom:12}}>
          {[
            ['Pojazd', vehicle.id],
            ['Zajezdnia', vehicle.depot],
            ['Kierunek', vehicle.direction],
            ['Prędkość', `${vehicle.speed} km/h`],
          ].map(([k,v])=>(
            <div key={k} style={{background:'var(--surf2)',borderRadius:6,padding:'8px 10px',border:'1px solid var(--border)'}}>
              <div style={{fontSize:9,color:'var(--text-dim)',textTransform:'uppercase',letterSpacing:'0.06em',marginBottom:3}}>{k}</div>
              <div style={{fontFamily:'var(--mono)',fontSize:13}}>{v}</div>
            </div>
          ))}
        </div>
        <div style={{background:'var(--surf2)',borderRadius:8,padding:'10px 12px',border:'1px solid var(--border)',marginBottom:12}}>
          <div style={{fontSize:10,color:'var(--text-dim)',textTransform:'uppercase',letterSpacing:'0.06em',marginBottom:6}}>Punktualność</div>
          <div style={{display:'flex',alignItems:'baseline',gap:6}}>
            <span style={{fontFamily:'var(--mono)',fontSize:22,fontWeight:600,color:dc}}>{delayLabel(vehicle.delay)}</span>
          </div>
          <div style={{height:4,background:'var(--surf3)',borderRadius:2,marginTop:8,overflow:'hidden'}}>
            <div style={{height:'100%',width:`${Math.min(100,Math.abs(vehicle.delay)/15*100)}%`,background:dc,borderRadius:2}}></div>
          </div>
        </div>
        <div style={{display:'flex',flexDirection:'column',gap:6}}>
          <button className="vtip-btn" onClick={onContact} style={{width:'100%',textAlign:'left',padding:'9px 12px',fontSize:12}}>
            ✉ Kontakt z kierowcą
          </button>
          <button className="vtip-btn" onClick={onStops} style={{width:'100%',textAlign:'left',padding:'9px 12px',fontSize:12}}>
            🚏 Zarządzanie przystankami
          </button>
          <button className="vtip-btn" onClick={onDetour} style={{width:'100%',textAlign:'left',padding:'9px 12px',fontSize:12}}>
            ⚠ Wyznacz objazd
          </button>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, {
  ContactModal, StopsModal, VehicleLoginModal, DetourModal,
  PunctualityPanel, VehicleDetailPanel,
  depotColor, delayColor, delayLabel,
});
