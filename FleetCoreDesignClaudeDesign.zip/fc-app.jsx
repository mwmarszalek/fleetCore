// fc-app.jsx — Main App
const { useState, useEffect, useRef, useCallback } = React;

// ── Clock ─────────────────────────────────────────────────
function Clock() {
  const [t, setT] = useState(new Date());
  useEffect(() => { const id = setInterval(()=>setT(new Date()),1000); return ()=>clearInterval(id); }, []);
  const pad = n => String(n).padStart(2,'0');
  return <span className="header-time">{pad(t.getHours())}:{pad(t.getMinutes())}:{pad(t.getSeconds())}</span>;
}

// ── LineBadge ─────────────────────────────────────────────
function LineBadge({ line, small }) {
  const depot = LINES_DATA.find(l=>l.id===line)?.depot || 'SPAK';
  const col = DEPOTS_DATA[depot].color;
  const size = small ? {width:28,height:17,fontSize:10} : {width:36,height:22,fontSize:11};
  return (
    <div className="line-badge" style={{...size, background:col+'18', color:col, border:`1px solid ${col}44`}}>
      {line}
    </div>
  );
}

// ── Sidebar — uproszczony, tylko moje linie ───────────────
function Sidebar({ myLines, vehicles, selectedLine, onSelectLine, watchedLines, onToggleWatch }) {
  const [filter, setFilter] = useState('');
  const [collapsed, setCollapsed] = useState({});
  const DEPOT_ORDER = ['SPAK','SPAD','SPPK','PKS','TRAM'];

  function vehicleChipColor(delay) {
    if (delay < -8)  return { bg:'rgba(248,81,73,0.22)',  border:'rgba(248,81,73,0.6)',  text:'#f85149' };
    if (delay < -3)  return { bg:'rgba(248,81,73,0.12)',  border:'rgba(248,81,73,0.35)', text:'#f87171' };
    if (delay <= 0)  return { bg:'rgba(125,133,144,0.12)', border:'rgba(125,133,144,0.3)', text:'#8b949e' };
    if (delay <= 2)  return { bg:'rgba(88,166,255,0.10)', border:'rgba(88,166,255,0.3)', text:'#79b8ff' };
    return               { bg:'rgba(88,166,255,0.20)',  border:'rgba(88,166,255,0.55)', text:'#58a6ff' };
  }
  function delayChipLabel(d) { return d===0?'0':d<0?`${d}`:`+${d}`; }

  const myArr = [...myLines].filter(id => !filter || id.toLowerCase().includes(filter.toLowerCase()));

  function byDepot(ids) {
    const groups = {};
    DEPOT_ORDER.forEach(d=>{groups[d]=[];});
    ids.forEach(id=>{
      const d = LINES_DATA.find(l=>l.id===id)?.depot||'SPAK';
      if(groups[d]) groups[d].push(id);
    });
    return DEPOT_ORDER.filter(d=>groups[d].length>0).map(d=>({depot:d,lines:groups[d]}));
  }

  function DepotGroup({ depot, lines }) {
    const col = DEPOTS_DATA[depot].color;
    const isOpen = collapsed[depot] !== false;
    return (
      <div>
        <div onClick={()=>setCollapsed(c=>({...c,[depot]:!isOpen}))}
          style={{display:'flex',alignItems:'center',gap:6,padding:'5px 12px 4px',cursor:'pointer',userSelect:'none'}}>
          <div style={{width:3,height:12,borderRadius:2,background:col,flexShrink:0}}></div>
          <span style={{fontSize:10,fontWeight:600,color:col,letterSpacing:'0.06em',textTransform:'uppercase'}}>{DEPOTS_DATA[depot].label}</span>
          <span style={{fontFamily:'var(--mono)',fontSize:9,color:'var(--text-dim)',marginLeft:2}}>{lines.length}</span>
          <span style={{fontSize:8,color:'var(--text-dim)',marginLeft:'auto',transform:isOpen?'none':'rotate(-90deg)',transition:'transform 0.15s'}}>▼</span>
        </div>
        {isOpen && lines.map(id => {
          const vs = [...vehicles.filter(v=>v.line===id)].sort((a,b)=>a.delay-b.delay);
          const isWatched = watchedLines.has(id);
          const col = DEPOTS_DATA[depot].color;
          return (
            <div key={id} className={`line-row ${selectedLine===id?'active':''}`}
              style={{flexDirection:'column',alignItems:'flex-start',gap:4,paddingBottom:6,borderLeft:isWatched?`2px solid ${col}`:'2px solid transparent'}}
              onClick={()=>onSelectLine(id)}>
              <div style={{display:'flex',alignItems:'center',width:'100%',gap:6}}>
                <LineBadge line={id} small/>
                <span style={{fontSize:12,fontWeight:500,color:'var(--text)',flex:1}}>{id}</span>
                <span style={{fontFamily:'var(--mono)',fontSize:10,color:'var(--text-dim)'}}>{vs.length}×</span>
                <button
                  title={isWatched?'Usuń z diagramu':'Dodaj do diagramu ruchu (max 3)'}
                  onClick={e=>{e.stopPropagation();onToggleWatch(id);}}
                  style={{width:18,height:18,borderRadius:3,border:`1px solid ${isWatched?col:'var(--border2)'}`,background:isWatched?col+'22':'transparent',color:isWatched?col:'var(--text-off)',fontSize:9,cursor:'pointer',display:'flex',alignItems:'center',justifyContent:'center',flexShrink:0,transition:'all 0.12s'}}>
                  {isWatched?'◉':'◎'}
                </button>
              </div>
              {vs.length>0 && (
                <div style={{display:'flex',flexWrap:'wrap',gap:3,paddingLeft:2,width:'100%'}}>
                  {vs.map(v=>{
                    const c=vehicleChipColor(v.delay);
                    return (
                      <div key={v.id} title={`${v.brigade} → ${v.direction}`}
                        style={{display:'flex',alignItems:'center',gap:3,padding:'1px 5px',borderRadius:3,background:c.bg,border:`1px solid ${c.border}`,fontFamily:'var(--mono)',fontSize:10,cursor:'default'}}>
                        <span style={{color:'var(--text-dim)'}}>{v.id}</span>
                        <span style={{color:c.text,fontWeight:600}}>{delayChipLabel(v.delay)}</span>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          );
        })}
      </div>
    );
  }

  return (
    <div className="app-sidebar">
      <div className="sidebar-search">
        <input className="search-input" value={filter} onChange={e=>setFilter(e.target.value)} placeholder="Szukaj linii…"/>
      </div>
      <div style={{padding:'6px 12px',borderBottom:'1px solid var(--border)',display:'flex',alignItems:'center',justifyContent:'space-between'}}>
        <span style={{fontSize:10,fontWeight:600,textTransform:'uppercase',letterSpacing:'0.08em',color:'var(--text-dim)'}}>Moje linie</span>
        <span style={{fontFamily:'var(--mono)',fontSize:10,color:'var(--text-dim)',background:'var(--surf2)',borderRadius:10,padding:'1px 6px'}}>{myArr.length}</span>
      </div>
      {myArr.length===0 && (
        <div style={{padding:'16px 14px',fontSize:11,color:'var(--text-dim)',textAlign:'center',lineHeight:1.5}}>
          Brak kontrolowanych linii.<br/>
          <span style={{color:'var(--spak)'}}>Użyj przycisku „Kontrola Linii"</span><br/>aby przejąć linie.
        </div>
      )}
      <div style={{flex:1,overflowY:'auto'}}>
        {byDepot(myArr).map(({depot,lines})=>(
          <DepotGroup key={depot} depot={depot} lines={lines}/>
        ))}
      </div>
    </div>
  );
}

// ── LineControlModal ──────────────────────────────────────
function LineControlModal({ myLines, dispatchers, onTake, onRelease, onClose }) {
  const [filter, setFilter] = useState('');
  const [depotFilter, setDepotFilter] = useState('ALL');
  const DEPOT_ORDER = ['SPAK','SPAD','SPPK','PKS','TRAM'];

  const controllerOf = line => dispatchers.find(d=>d.lines.includes(line));

  const filtered = id => {
    if (filter && !id.toLowerCase().includes(filter.toLowerCase())) return false;
    if (depotFilter!=='ALL') {
      const d = LINES_DATA.find(l=>l.id===id)?.depot;
      if (d!==depotFilter) return false;
    }
    return true;
  };

  function byDepot(ids) {
    const groups={};
    DEPOT_ORDER.forEach(d=>{groups[d]=[];});
    ids.forEach(id=>{
      const d=LINES_DATA.find(l=>l.id===id)?.depot||'SPAK';
      if(groups[d]) groups[d].push(id);
    });
    return DEPOT_ORDER.filter(d=>groups[d].length>0).map(d=>({depot:d,lines:groups[d]}));
  }

  function availableInDepot(depot) {
    return LINES_DATA.filter(l=>l.depot===depot).map(l=>l.id)
      .filter(id=>!myLines.has(id)&&!controllerOf(id));
  }

  const allLines = LINES_DATA.map(l=>l.id).filter(filtered);

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal" onClick={e=>e.stopPropagation()} style={{minWidth:560,maxWidth:660,maxHeight:'82vh',display:'flex',flexDirection:'column',padding:0,overflow:'hidden',borderRadius:10}}>

        {/* Header */}
        <div style={{padding:'14px 18px 10px',borderBottom:'1px solid var(--border)'}}>
          <div style={{display:'flex',alignItems:'center',gap:10,marginBottom:8}}>
            <span style={{fontSize:14,fontWeight:600}}>Kontrola linii</span>
            <div style={{marginLeft:'auto',display:'flex',alignItems:'center',gap:8}}>
              <span style={{fontFamily:'var(--mono)',fontSize:12,color:'var(--text-dim)'}}>
                Kontrolujesz: <strong style={{color:'var(--spak)'}}>{myLines.size}</strong> linii
              </span>
              {myLines.size>0&&(
                <button onClick={()=>[...myLines].forEach(onRelease)} style={{padding:'3px 10px',borderRadius:4,fontSize:10,cursor:'pointer',border:'1px solid var(--border2)',background:'none',color:'var(--text-dim)',fontFamily:'var(--font)'}}
                  onMouseOver={e=>{e.currentTarget.style.borderColor='#f85149';e.currentTarget.style.color='#f85149';}}
                  onMouseOut={e=>{e.currentTarget.style.borderColor='var(--border2)';e.currentTarget.style.color='var(--text-dim)';}}>
                  Zdaj wszystkie
                </button>
              )}
            </div>
          </div>
          <div style={{display:'flex',gap:4,flexWrap:'wrap'}}>
            <input className="search-input" style={{width:160,flexShrink:0}} value={filter} onChange={e=>setFilter(e.target.value)} placeholder="Szukaj linii…"/>
            {[['ALL','Wszystkie'],['SPAK','SPAK'],['SPAD','SPAD'],['SPPK','SPPK'],['PKS','PKS'],['TRAM','Tram']].map(([k,l])=>{
              const active=depotFilter===k;
              const c=k==='ALL'?'#60a5fa':DEPOTS_DATA[k]?.color||'#60a5fa';
              return (
                <button key={k} onClick={()=>setDepotFilter(k)} style={{padding:'3px 9px',borderRadius:4,fontSize:10,cursor:'pointer',fontFamily:'var(--mono)',border:`1px solid ${active?c:'var(--border2)'}`,background:active?c+'18':'transparent',color:active?c:'var(--text-dim)',transition:'all 0.12s'}}>{l}</button>
              );
            })}
          </div>
        </div>

        {/* Line list */}
        <div style={{flex:1,overflowY:'auto'}}>
          {byDepot(allLines).map(({depot,lines})=>{
            const col=DEPOTS_DATA[depot].color;
            const avail=availableInDepot(depot).filter(filtered);
            const myInDepot=lines.filter(id=>myLines.has(id));
            return (
              <div key={depot}>
                <div style={{padding:'6px 14px',background:'var(--surf2)',borderBottom:'1px solid var(--border)',borderTop:'1px solid var(--border)',display:'flex',alignItems:'center',gap:8,position:'sticky',top:0,zIndex:1}}>
                  <div style={{width:3,height:14,borderRadius:2,background:col,flexShrink:0}}/>
                  <span style={{fontSize:11,fontWeight:600,color:col,textTransform:'uppercase',letterSpacing:'0.06em'}}>{DEPOTS_DATA[depot].label}</span>
                  <span style={{fontFamily:'var(--mono)',fontSize:9,color:'var(--text-dim)'}}>{myInDepot.length}/{lines.length}</span>
                  <div style={{marginLeft:'auto',display:'flex',gap:5}}>
                    {avail.length>0&&(
                      <button onClick={()=>avail.forEach(onTake)} style={{padding:'3px 10px',borderRadius:4,fontSize:10,cursor:'pointer',fontFamily:'var(--font)',border:`1px solid ${col}55`,background:col+'0d',color:col,transition:'all 0.12s'}}
                        onMouseOver={e=>{e.currentTarget.style.background=col+'22';}}
                        onMouseOut={e=>{e.currentTarget.style.background=col+'0d';}}>
                        Przejmij dostępne ({avail.length})
                      </button>
                    )}
                    {myInDepot.length>0&&(
                      <button onClick={()=>myInDepot.forEach(onRelease)} style={{padding:'3px 10px',borderRadius:4,fontSize:10,cursor:'pointer',fontFamily:'var(--font)',border:'1px solid var(--border2)',background:'none',color:'var(--text-dim)',transition:'all 0.12s'}}
                        onMouseOver={e=>{e.currentTarget.style.borderColor='#f85149';e.currentTarget.style.color='#f85149';}}
                        onMouseOut={e=>{e.currentTarget.style.borderColor='var(--border2)';e.currentTarget.style.color='var(--text-dim)';}}>
                        Zdaj zajezdnię
                      </button>
                    )}
                  </div>
                </div>
                <div style={{display:'flex',flexWrap:'wrap',gap:4,padding:'8px 14px'}}>
                  {lines.map(id=>{
                    const isMine=myLines.has(id);
                    const ctrl=!isMine&&controllerOf(id);
                    const lcol=DEPOTS_DATA[LINES_DATA.find(l=>l.id===id)?.depot||'SPAK'].color;
                    return (
                      <div key={id} style={{display:'flex',alignItems:'center',gap:4,padding:'4px 7px',borderRadius:5,background:isMine?lcol+'18':'var(--surf2)',border:`1.5px solid ${isMine?lcol:'var(--border)'}`,opacity:ctrl?0.45:1,transition:'all 0.12s'}}>
                        <div style={{width:26,height:16,borderRadius:2,background:lcol+'22',color:lcol,border:`1px solid ${lcol}44`,display:'flex',alignItems:'center',justifyContent:'center',fontFamily:'var(--mono)',fontSize:9,fontWeight:700}}>{id}</div>
                        {isMine?(
                          <button onClick={()=>onRelease(id)} style={{padding:'1px 6px',borderRadius:3,border:'1px solid var(--border2)',background:'none',color:'var(--text-dim)',fontSize:9,cursor:'pointer',fontFamily:'var(--mono)'}}
                            onMouseOver={e=>{e.target.style.borderColor='#f85149';e.target.style.color='#f85149';}}
                            onMouseOut={e=>{e.target.style.borderColor='var(--border2)';e.target.style.color='var(--text-dim)';}}>zdaj</button>
                        ):ctrl?(
                          <span style={{fontSize:8,color:'var(--text-off)',fontFamily:'var(--mono)'}}>zajęta</span>
                        ):(
                          <button onClick={()=>onTake(id)} style={{padding:'1px 6px',borderRadius:3,border:`1px solid ${lcol}55`,background:'none',color:lcol,fontSize:9,cursor:'pointer',fontFamily:'var(--mono)'}}
                            onMouseOver={e=>{e.target.style.background=lcol+'22';}}
                            onMouseOut={e=>{e.target.style.background='none';}}>przejmij</button>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>

        <div style={{padding:'10px 16px',borderTop:'1px solid var(--border)',display:'flex',justifyContent:'flex-end'}}>
          <button className="btn-primary" onClick={onClose}>Zamknij</button>
        </div>
      </div>
    </div>
  );
}

// ── DiagramRuchu ──────────────────────────────────────────
function DiagramRuchu({ watchedLines, vehicles, onClose }) {
  const [activeTab, setActiveTab] = useState(null);
  const lines = [...watchedLines].sort();

  // Auto-select first tab
  const tab = activeTab && watchedLines.has(activeTab) ? activeTab : lines[0];

  const RAIL_W = 480;
  const STOPS_COUNT = 7;

  function getStops(lineId) {
    const raw = STOPS_BY_LINE[lineId];
    if (raw) return raw.map(s=>s.name);
    const dirs = LINE_DIRECTIONS[lineId]||['Pętla A','Pętla B'];
    const pool = ['Centrum','Rynek','Dworzec PKP','Ul. Główna','Plac Wolności','Os. Słoneczne','Ul. Leśna','Szpital','Ul. Krakowska','Plac Niepodległości'];
    const seed = lineId.split('').reduce((a,c)=>a+c.charCodeAt(0),0);
    const n = 3+(seed%3);
    const mids=[];
    for(let i=0;i<n;i++) mids.push(pool[(seed*3+i*7)%pool.length]);
    return [dirs[0],...mids,dirs[1]];
  }

  // Place vehicles evenly — avoid overlap by bucketing into lanes
  function placeVehicles(vs, width) {
    // sort by id-based progress
    const placed = vs.map(v=>{
      const seed=parseInt(v.id.replace(/\D/g,''))||1;
      return {...v, pct:(seed%100)/100};
    }).sort((a,b)=>a.pct-b.pct);

    // Resolve overlaps: if two vehicles within 40px, stagger vertically
    const CHIP_W=60, lanes=[];
    return placed.map(v=>{
      const x=v.pct*width;
      let lane=0;
      while(lanes[lane]!==undefined && x-lanes[lane]<CHIP_W) lane++;
      lanes[lane]=x;
      return {...v, x, lane};
    });
  }

  function Rail({ lineId, vehicles, direction, color }) {
    const [hov,setHov]=useState(null);
    const stops=getStops(lineId);
    const placed=placeVehicles(vehicles, RAIL_W);
    const maxLane=Math.max(0,...placed.map(v=>v.lane));
    const railH=42+maxLane*22;

    return (
      <div style={{marginBottom:6}}>
        <div style={{fontSize:9,color:'var(--text-dim)',fontFamily:'var(--mono)',marginBottom:3,paddingLeft:2}}>→ {direction}</div>
        <div style={{position:'relative',height:railH,width:RAIL_W}}>
          {/* track */}
          <div style={{position:'absolute',top:20,left:0,right:0,height:2,background:color+'33',borderRadius:1}}/>
          {/* stops */}
          {stops.map((s,i)=>{
            const x=(i/(stops.length-1))*RAIL_W;
            const isTerm=i===0||i===stops.length-1;
            const above=i%2===0;
            return (
              <div key={i} style={{position:'absolute',left:x,top:0,transform:'translateX(-50%)'}}>
                <div style={{position:'absolute',top:15,left:'50%',width:isTerm?9:5,height:isTerm?9:5,borderRadius:'50%',background:isTerm?color:'var(--surf3)',border:`2px solid ${isTerm?color:color+'55'}`,transform:'translate(-50%,-50%)'}}/>
                <div style={{position:'absolute',[above?'top':'bottom']:25,left:'50%',transform:'translateX(-50%)',fontSize:8,color:isTerm?color:'var(--text-dim)',whiteSpace:'nowrap',fontWeight:isTerm?600:400,maxWidth:80,textAlign:'center',overflow:'hidden',textOverflow:'ellipsis'}}>
                  {s}
                </div>
              </div>
            );
          })}
          {/* vehicles */}
          {placed.map(v=>{
            const isH=hov===v.id;
            const dc=v.delay<-7?'#f85149':v.delay<-2?'#f87171':v.delay>1?'#79b8ff':'#8b949e';
            const dbg=v.delay<-7?'#7f1d1d':v.delay<-2?'#991b1b':v.delay>1?'#1e3a5f':'#1a1f27';
            const dlbl=v.delay===0?'0':v.delay>0?`+${v.delay}`:`${v.delay}`;
            const yOffset=20+v.lane*22;
            return (
              <div key={v.id}
                onMouseEnter={()=>setHov(v.id)}
                onMouseLeave={()=>setHov(null)}
                style={{position:'absolute',left:v.x,top:yOffset,transform:'translate(-50%,-50%)',zIndex:isH?20:3}}>
                {/* connector line if stacked */}
                {v.lane>0&&<div style={{position:'absolute',left:'50%',bottom:-2,width:1,height:v.lane*22,background:color+'33',transform:'translateX(-50%)',zIndex:1}}/>}
                <div style={{padding:'2px 6px',borderRadius:4,background:dbg,border:`1.5px solid ${dc}`,fontFamily:'var(--mono)',fontSize:9,fontWeight:600,color:dc,whiteSpace:'nowrap',boxShadow:isH?`0 0 10px ${dc}55`:`0 1px 4px rgba(0,0,0,0.5)`,transition:'all 0.1s',cursor:'default',zIndex:2,position:'relative'}}>
                  {v.id} <span style={{opacity:.85}}>{dlbl}</span>
                </div>
                {isH&&(
                  <div style={{position:'absolute',bottom:'calc(100%+5px)',left:'50%',transform:'translateX(-50%)',background:'var(--surf3)',border:'1px solid var(--border2)',borderRadius:6,padding:'5px 9px',whiteSpace:'nowrap',fontSize:10,zIndex:50,color:'var(--text)',boxShadow:'0 4px 16px rgba(0,0,0,0.7)',pointerEvents:'none'}}>
                    <div style={{fontFamily:'var(--mono)',fontWeight:500}}>{v.brigade}</div>
                    <div style={{fontSize:9,color:'var(--text-dim)'}}>→ {v.direction}</div>
                    <div style={{color:dc,fontFamily:'var(--mono)',fontWeight:700,marginTop:2}}>{dlbl} min · {v.speed?.toFixed(0)||'—'} km/h</div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    );
  }

  if (lines.length===0) return null;

  const depot = LINES_DATA.find(l=>l.id===tab)?.depot||'SPAK';
  const col = DEPOTS_DATA[depot].color;
  const allVs = vehicles.filter(v=>v.line===tab);
  const dirs = LINE_DIRECTIONS[tab]||['Kierunek A','Kierunek B'];
  // Split vehicles by direction (odd brigade = dir A, even = dir B — mock split)
  const vA = allVs.filter((_,i)=>i%2===0);
  const vB = allVs.filter((_,i)=>i%2===1);

  const delayed = allVs.filter(v=>v.delay<-2).length;
  const early   = allVs.filter(v=>v.delay>1).length;

  return (
    <div style={{
      position:'absolute', top:0, left:0, zIndex:40,
      width: RAIL_W+80,
      background:'rgba(16,21,28,0.97)',
      borderRight:'1px solid var(--border2)',
      borderBottom:'1px solid var(--border2)',
      borderRadius:'0 0 10px 0',
      boxShadow:'4px 4px 24px rgba(0,0,0,0.7)',
      backdropFilter:'blur(4px)',
      display:'flex', flexDirection:'column',
    }}>
      {/* Header tabs */}
      <div style={{display:'flex',alignItems:'center',borderBottom:'1px solid var(--border)',background:'var(--surf)',borderRadius:'0 0 0 0'}}>
        <span style={{fontSize:10,fontWeight:600,color:'var(--text-dim)',padding:'0 12px',textTransform:'uppercase',letterSpacing:'0.07em',flexShrink:0}}>Diagram ruchu</span>
        <div style={{display:'flex',flex:1,overflowX:'auto'}}>
          {lines.map(id=>{
            const d=LINES_DATA.find(l=>l.id===id)?.depot||'SPAK';
            const c=DEPOTS_DATA[d].color;
            const isAct=id===tab;
            const vs=vehicles.filter(v=>v.line===id);
            const worst=vs.length?Math.min(...vs.map(v=>v.delay)):0;
            const dc=worst<-5?'#f85149':worst<-2?'#f87171':worst>1?'#79b8ff':'#6b7280';
            return (
              <button key={id} onClick={()=>setActiveTab(id)} style={{
                display:'flex',alignItems:'center',gap:5,padding:'6px 12px',
                border:'none',borderBottom:isAct?`2px solid ${c}`:'2px solid transparent',
                marginBottom:-1,background:'transparent',cursor:'pointer',flexShrink:0,
              }}>
                <div style={{width:24,height:15,borderRadius:2,background:c+'22',border:`1px solid ${c}55`,display:'flex',alignItems:'center',justifyContent:'center',fontFamily:'var(--mono)',fontSize:9,fontWeight:700,color:c}}>{id}</div>
                {worst!==0&&<span style={{fontFamily:'var(--mono)',fontSize:8,fontWeight:700,color:dc}}>{worst>0?`+${worst}`:worst}</span>}
              </button>
            );
          })}
        </div>
        <button onClick={onClose} style={{width:32,height:32,border:'none',background:'none',color:'var(--text-dim)',cursor:'pointer',fontSize:12,flexShrink:0,borderLeft:'1px solid var(--border)'}}>✕</button>
      </div>

      {/* Stats bar */}
      <div style={{display:'flex',alignItems:'center',gap:14,padding:'5px 14px',borderBottom:'1px solid var(--border)',background:'var(--surf2)'}}>
        <span style={{fontFamily:'var(--mono)',fontSize:10,color:'var(--text-dim)'}}>
          {dirs[0]} <span style={{color:'var(--text-off)'}}>↔</span> {dirs[1]}
        </span>
        <span style={{fontFamily:'var(--mono)',fontSize:10,color:'var(--text-dim)'}}>
          {allVs.length} poj.
        </span>
        {delayed>0&&<span style={{fontFamily:'var(--mono)',fontSize:10,color:'#f87171'}}>▼ {delayed} opóźn.</span>}
        {early>0&&<span style={{fontFamily:'var(--mono)',fontSize:10,color:'#79b8ff'}}>▲ {early} przysp.</span>}
      </div>

      {/* Rails */}
      <div style={{padding:'10px 14px 8px',overflowX:'auto'}}>
        <Rail lineId={tab} vehicles={vA} direction={dirs[1]} color={col}/>
        <Rail lineId={tab} vehicles={vB} direction={dirs[0]} color={col}/>
      </div>
    </div>
  );
}


function RouteView({ myLines, vehicles }) {
  const lines = [...myLines].sort();
  const [selectedLine, setSelectedLine] = useState(null);
  const [collapsed, setCollapsed] = useState(false);

  // Auto-select first line
  const activeLine = selectedLine && myLines.has(selectedLine) ? selectedLine : lines[0] || null;

  function getStops(lineId) {
    const raw = STOPS_BY_LINE[lineId];
    if (raw) return raw.map(s=>s.name);
    const dirs = LINE_DIRECTIONS[lineId] || ['Pętla A','Pętla B'];
    const midStops = ['Centrum','Rynek','Dworzec PKP','Ul. Główna','Plac Wolności','Os. Słoneczne','Ul. Leśna','Szpital'];
    const seed = lineId.split('').reduce((a,c)=>a+c.charCodeAt(0),0);
    const n = 3 + (seed % 3);
    const mids = [];
    for (let i=0;i<n;i++) mids.push(midStops[(seed*3+i*7)%midStops.length]);
    return [dirs[0], ...mids, dirs[1]];
  }

  function getVehicleProgress(v) {
    const seed = parseInt(v.id.replace(/\D/g,''))||1;
    return (seed % 100) / 100;
  }

  if (lines.length === 0) return (
    <div style={{borderTop:'1px solid var(--border)',background:'var(--surf)',padding:'8px 16px',color:'var(--text-dim)',fontSize:11,textAlign:'center',flexShrink:0}}>
      Przejmij linie aby zobaczyć diagram tras.
    </div>
  );

  const depot = activeLine ? (LINES_DATA.find(l=>l.id===activeLine)?.depot||'SPAK') : 'SPAK';
  const col = activeLine ? DEPOTS_DATA[depot].color : 'var(--spak)';
  const vs = activeLine ? vehicles.filter(v=>v.line===activeLine) : [];
  const stops = activeLine ? getStops(activeLine) : [];
  const dirs = activeLine ? (LINE_DIRECTIONS[activeLine]||[stops[0],stops[stops.length-1]]) : [];

  return (
    <div style={{borderTop:'1px solid var(--border)',background:'var(--surf)',flexShrink:0}}>
      {/* Tab bar */}
      <div style={{display:'flex',alignItems:'center',borderBottom:collapsed?'none':'1px solid var(--border)',overflowX:'auto',gap:0,minHeight:30}}>
        <div style={{display:'flex',alignItems:'center',flex:1,overflowX:'auto',gap:1,padding:'3px 6px'}}>
          {lines.map(id=>{
            const d = LINES_DATA.find(l=>l.id===id)?.depot||'SPAK';
            const c = DEPOTS_DATA[d].color;
            const isActive = id===activeLine;
            const lineVs = vehicles.filter(v=>v.line===id);
            const worst = lineVs.length ? Math.min(...lineVs.map(v=>v.delay)) : 0;
            const dc = worst<-5?'#f85149':worst<-2?'#f87171':worst>1?'#79b8ff':'#8b949e';
            return (
              <button key={id} onClick={()=>{setSelectedLine(id);setCollapsed(false);}}
                style={{
                  display:'flex',alignItems:'center',gap:4,
                  padding:'3px 8px',borderRadius:5,border:'none',
                  background:isActive?c+'22':'transparent',
                  cursor:'pointer',flexShrink:0,transition:'all 0.12s',
                  borderBottom:isActive?`2px solid ${c}`:'2px solid transparent',
                  marginBottom:-1,
                }}>
                <div style={{width:22,height:14,borderRadius:2,background:c+'22',border:`1px solid ${c}55`,display:'flex',alignItems:'center',justifyContent:'center',fontFamily:'var(--mono)',fontSize:9,fontWeight:700,color:c}}>{id}</div>
                {worst!==0&&<span style={{fontFamily:'var(--mono)',fontSize:8,fontWeight:700,color:dc}}>{worst>0?`+${worst}`:worst}</span>}
              </button>
            );
          })}
        </div>
        {/* Collapse toggle */}
        <button onClick={()=>setCollapsed(c=>!c)} style={{
          flexShrink:0,width:28,height:28,display:'flex',alignItems:'center',justifyContent:'center',
          border:'none',background:'none',cursor:'pointer',color:'var(--text-dim)',
          borderLeft:'1px solid var(--border)',
          fontSize:10,
        }} title={collapsed?'Rozwiń':'Zwiń'}>
          {collapsed?'▲':'▼'}
        </button>
      </div>

      {/* Route diagram */}
      {!collapsed && activeLine && (
        <div style={{padding:'8px 14px 6px',minWidth:600,overflowX:'auto'}}>
          <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:6}}>
            <span style={{fontSize:10,color:'var(--text-dim)'}}>{dirs[0]} ↔ {dirs[1]}</span>
            <span style={{fontFamily:'var(--mono)',fontSize:9,color:'var(--text-dim)',marginLeft:4}}>{vs.length} pojazd.</span>
            {vs.length>0&&<span style={{fontFamily:'var(--mono)',fontSize:9,color:'var(--text-dim)'}}>
              ø {(vs.reduce((s,v)=>s+v.delay,0)/vs.length).toFixed(1)} min
            </span>}
          </div>
          <div style={{position:'relative',height:60,marginRight:10}}>
            <div style={{position:'absolute',top:28,left:0,right:0,height:2,background:col+'44',borderRadius:2}}/>
            {stops.map((stop,i)=>{
              const pct=i/(stops.length-1);
              const isTerminal=i===0||i===stops.length-1;
              const above=i%2===0;
              return (
                <div key={i} style={{position:'absolute',left:`${pct*100}%`,top:0,transform:'translateX(-50%)',height:'100%'}}>
                  <div style={{position:'absolute',[above?'bottom':'top']:32,fontSize:8,color:isTerminal?col:'var(--text-dim)',whiteSpace:'nowrap',fontWeight:isTerminal?600:400,transform:'translateX(-50%)',maxWidth:90,textAlign:'center',overflow:'hidden',textOverflow:'ellipsis'}}>
                    {stop}
                  </div>
                  <div style={{position:'absolute',top:24,left:'50%',width:isTerminal?10:6,height:isTerminal?10:6,borderRadius:'50%',background:isTerminal?col:'var(--surf3)',border:`2px solid ${isTerminal?col:col+'66'}`,transform:'translate(-50%,-50%)'}}/>
                </div>
              );
            })}
            {vs.map(v=>{
              const prog=getVehicleProgress(v);
              const dc=v.delay<-2?'#f85149':v.delay>1?'#79b8ff':'#8b949e';
              const dlbl=v.delay===0?'0':v.delay>0?`+${v.delay}`:`${v.delay}`;
              return (
                <div key={v.id} style={{position:'absolute',left:`${prog*100}%`,top:28,transform:'translate(-50%,-50%)',zIndex:5}}>
                  <div title={`${v.brigade} · ${dlbl} min`} style={{display:'flex',flexDirection:'column',alignItems:'center',gap:1}}>
                    <div style={{padding:'1px 5px',borderRadius:3,background:'var(--surf)',border:`1.5px solid ${col}`,fontFamily:'var(--mono)',fontSize:8,fontWeight:600,color:col,whiteSpace:'nowrap',boxShadow:`0 0 6px ${col}44`}}>{v.id}</div>
                    <div style={{fontFamily:'var(--mono)',fontSize:8,fontWeight:700,color:dc}}>{dlbl}</div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}


// ── MapView ───────────────────────────────────────────────
function MapView({ vehicles, myLines, selectedLine, selectedVehicle, onSelectVehicle, showAllRoutes }) {
  const containerRef = useRef(null);
  const mapRef = useRef(null);
  const routeLayersRef = useRef({});
  const markerLayersRef = useRef({});
  const tooltipRef = useRef(null);
  const [tooltip, setTooltip] = useState(null); // {vehicle, x, y}

  // Init map
  useEffect(() => {
    if (mapRef.current) return;
    const map = L.map(containerRef.current, {
      center: [53.4285, 14.5528], zoom: 13,
      zoomControl: false, attributionControl: false,
    });
    L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 19,
    }).addTo(map);
    // Dark map via CSS invert
    const style = document.createElement('style');
    style.textContent = '.leaflet-tile-pane { filter: invert(1) hue-rotate(180deg) brightness(0.9) contrast(0.85) saturate(0.6); }';
    document.head.appendChild(style);
    L.control.zoom({ position: 'bottomright' }).addTo(map);
    mapRef.current = map;
    return () => { map.remove(); mapRef.current = null; };
  }, []);

  // Update routes
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;
    // Clear old route layers
    Object.values(routeLayersRef.current).forEach(l => map.removeLayer(l));
    routeLayersRef.current = {};

    const linesToShow = showAllRoutes
      ? Object.keys(ROUTE_PATHS)
      : [...myLines, ...(selectedLine ? [selectedLine] : [])];

    linesToShow.forEach(lineId => {
      const path = ROUTE_PATHS[lineId];
      if (!path) return;
      const depot = LINES_DATA.find(l=>l.id===lineId)?.depot || 'SPAK';
      const col = DEPOTS_DATA[depot].color;
      const isSelected = lineId === selectedLine;
      const isMine = myLines.has(lineId);
      const layer = L.polyline(path, {
        color: col,
        weight: isSelected ? 5 : isMine ? 3 : 1.5,
        opacity: isSelected ? 1 : isMine ? 0.7 : 0.3,
        dashArray: isMine || isSelected ? null : '4 4',
      }).addTo(map);
      routeLayersRef.current[lineId] = layer;
    });
  }, [myLines, selectedLine, showAllRoutes]);

  // Update vehicle markers
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;
    Object.values(markerLayersRef.current).forEach(m => map.removeLayer(m));
    markerLayersRef.current = {};

    const visibleVehicles = vehicles.filter(v =>
      myLines.has(v.line) || v.line === selectedLine
    );

    visibleVehicles.forEach(v => {
      const depot = DEPOTS_DATA[v.depot];
      const col = depot.color;
      const dc = v.delay > 2 ? '#f85149' : v.delay < -1 ? '#58a6ff' : '#3fb950';
      const isSelected = selectedVehicle?.id === v.id;

      const icon = L.divIcon({
        html: `<div class="vm" style="border-color:${col};${isSelected?'transform:scale(1.15);box-shadow:0 0 0 2px '+col+',0 4px 12px rgba(0,0,0,0.6)':''}" data-vid="${v.id}">
          <div class="vm-dot" style="background:${dc}"></div>
          <span class="vm-line" style="color:${col}">${v.line}</span>
          <span class="vm-id">${v.id}</span>
        </div>`,
        className: '',
        iconSize: [62, 26],
        iconAnchor: [31, 13],
      });

      const marker = L.marker([v.lat, v.lng], { icon })
        .addTo(map)
        .on('click', () => onSelectVehicle(v))
        .on('mouseover', (e) => {
          const pt = map.latLngToContainerPoint([v.lat, v.lng]);
          setTooltip({ vehicle: v, x: pt.x, y: pt.y });
        })
        .on('mouseout', () => setTooltip(null));

      markerLayersRef.current[v.id] = marker;
    });
  }, [vehicles, myLines, selectedLine, selectedVehicle]);

  return (
    <div style={{position:'relative',width:'100%',height:'100%'}}>
      <div ref={containerRef} id="leaflet-map" style={{width:'100%',height:'100%'}}></div>

      {tooltip && (
        <VehicleTooltipOverlay
          vehicle={tooltip.vehicle}
          x={tooltip.x} y={tooltip.y}
          onClose={()=>setTooltip(null)}
          onSelect={()=>{ onSelectVehicle(tooltip.vehicle); setTooltip(null); }}
        />
      )}
    </div>
  );
}

// ── VehicleTooltipOverlay ─────────────────────────────────
function VehicleTooltipOverlay({ vehicle, x, y, onClose, onSelect }) {
  const col = DEPOTS_DATA[vehicle.depot].color;
  const dc = delayColor(vehicle.delay);
  const style = {
    position:'absolute', left: Math.min(x+10, window.innerWidth-220), top: Math.max(y-120, 10),
    zIndex:500, pointerEvents:'none',
  };
  return (
    <div className="vtip" style={style}>
      <div className="vtip-header">
        <div className="vtip-line" style={{background:col+'22',color:col,border:`1px solid ${col}55`}}>{vehicle.line}</div>
        <div>
          <div className="vtip-brig">{vehicle.brigade}</div>
          <div style={{fontFamily:'var(--mono)',fontSize:10,color:'var(--text-dim)'}}>{vehicle.depot}</div>
        </div>
      </div>
      <div className="vtip-dir">→ {vehicle.direction}</div>
      {[['Pojazd',vehicle.id],['Prędkość',`${vehicle.speed} km/h`],['Opóźnienie', <span style={{color:dc,fontWeight:600}}>{delayLabel(vehicle.delay)}</span>]].map(([k,v])=>(
        <div key={k} className="vtip-row"><span>{k}</span><span className="vtip-val">{v}</span></div>
      ))}
    </div>
  );
}

// ── StatusRibbon ──────────────────────────────────────────
function StatusRibbon({ vehicles, myLines, onSelectVehicle }) {
  const [hovered, setHovered] = useState(null);
  const lines = [...myLines].sort();

  function delayBgLocal(d) {
    if (d < -10) return '#7f1d1d';
    if (d < -5)  return '#991b1b';
    if (d < -2)  return '#b91c1c';
    if (d < 0)   return '#1f2937';
    if (d === 0) return '#161b22';
    if (d <= 2)  return '#1e3a5f';
    return '#1e3a8a';
  }

  return (
    <div style={{
      borderTop:'1px solid var(--border)',
      background:'var(--surf)',
      padding:'5px 10px',
      display:'flex',
      flexDirection:'column',
      gap:4,
      maxHeight:120,
      overflowY:'auto',
      flexShrink:0,
    }}>
      {lines.map(lineId => {
        const col = DEPOTS_DATA[LINES_DATA.find(l=>l.id===lineId)?.depot||'SPAK'].color;
        const vs = [...vehicles.filter(v=>v.line===lineId)].sort((a,b)=>a.delay-b.delay);
        if (vs.length===0) return null;
        const avgDelay = vs.reduce((s,v)=>s+v.delay,0)/vs.length;
        const worstDelay = vs[0].delay;
        return (
          <div key={lineId} style={{display:'flex',alignItems:'center',gap:6,minHeight:22}}>
            {/* Line badge */}
            <div style={{width:30,height:18,borderRadius:3,background:col+'22',border:`1px solid ${col}44`,display:'flex',alignItems:'center',justifyContent:'center',fontFamily:'var(--mono)',fontSize:10,fontWeight:600,color:col,flexShrink:0}}>
              {lineId}
            </div>
            {/* Avg */}
            <div style={{fontFamily:'var(--mono)',fontSize:10,fontWeight:600,color:delayColor(Math.round(avgDelay)),width:30,flexShrink:0,textAlign:'right'}}>
              ø{delayLabel(Math.round(avgDelay)).replace(' min','').replace('o czasie','0')}
            </div>
            {/* Divider */}
            <div style={{width:1,height:14,background:'var(--border2)',flexShrink:0}}/>
            {/* Vehicle chips */}
            <div style={{display:'flex',gap:2,flexWrap:'nowrap',overflow:'hidden'}}>
              {vs.map(v => {
                const isHov = hovered===v.id;
                const fg = delayColor(v.delay)==='var(--delayed)' ? '#f87171'
                  : delayColor(v.delay)==='var(--early)' ? '#79b8ff' : '#6b7280';
                const dlbl = v.delay===0?'0':v.delay>0?`+${v.delay}`:`${v.delay}`;
                return (
                  <div key={v.id} style={{position:'relative'}}
                    onMouseEnter={()=>setHovered(v.id)}
                    onMouseLeave={()=>setHovered(null)}
                    onClick={()=>onSelectVehicle(v)}>
                    <div style={{
                      height:18,padding:'0 5px',borderRadius:3,
                      background:delayBgLocal(v.delay),
                      border:`1px solid ${fg}44`,
                      display:'flex',alignItems:'center',gap:3,
                      fontFamily:'var(--mono)',fontSize:9,cursor:'pointer',
                      transition:'all 0.1s',
                      transform:isHov?'translateY(-2px)':'none',
                      whiteSpace:'nowrap',
                    }}>
                      <span style={{color:'var(--text-dim)',fontSize:8}}>{v.id}</span>
                      <span style={{color:fg,fontWeight:700}}>{dlbl}</span>
                    </div>
                    {isHov && (
                      <div style={{position:'absolute',bottom:'calc(100% + 4px)',left:0,background:'var(--surf3)',border:'1px solid var(--border2)',borderRadius:5,padding:'4px 8px',whiteSpace:'nowrap',fontSize:10,zIndex:200,color:'var(--text)',boxShadow:'0 4px 12px rgba(0,0,0,0.6)',pointerEvents:'none'}}>
                        <div style={{fontFamily:'var(--mono)',fontWeight:500}}>{v.brigade}</div>
                        <div style={{fontSize:9,color:'var(--text-dim)'}}>→ {v.direction}</div>
                        <div style={{color:fg,fontFamily:'var(--mono)',fontWeight:700,marginTop:2}}>{dlbl} min · {v.speed.toFixed(0)} km/h</div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
            {/* Worst indicator */}
            {worstDelay < -4 && (
              <div style={{marginLeft:'auto',flexShrink:0,display:'flex',alignItems:'center',gap:3,padding:'1px 6px',borderRadius:3,background:'rgba(248,81,73,0.08)',border:'1px solid rgba(248,81,73,0.25)'}}>
                <div style={{width:4,height:4,borderRadius:'50%',background:'#f85149',boxShadow:'0 0 4px #f85149'}}/>
                <span style={{fontFamily:'var(--mono)',fontSize:9,color:'#f85149'}}>{worstDelay} min</span>
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}


function BrigadesTab({ vehicles, myLines }) {
  const [search, setSearch] = useState('');
  const vs = vehicles.filter(v =>
    myLines.has(v.line) &&
    (!search || v.id.includes(search) || v.brigade.includes(search) || v.line.includes(search))
  );
  return (
    <div style={{flex:1,overflow:'auto',padding:16}}>
      <div style={{marginBottom:12,display:'flex',gap:8,alignItems:'center'}}>
        <input className="search-input" style={{maxWidth:240}} value={search} onChange={e=>setSearch(e.target.value)} placeholder="Szukaj pojazdu / brygady…"/>
        <span style={{fontSize:11,color:'var(--text-dim)',fontFamily:'var(--mono)'}}>{vs.length} pojazdów</span>
      </div>
      <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fill,minmax(240px,1fr))',gap:8}}>
        {vs.map(v=>{
          const col = DEPOTS_DATA[v.depot].color;
          const dc = delayColor(v.delay);
          return (
            <div key={v.id} style={{background:'var(--surf)',border:'1px solid var(--border)',borderRadius:8,padding:'10px 12px',borderLeft:`3px solid ${col}`}}>
              <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:6}}>
                <div style={{width:32,height:20,borderRadius:3,background:col+'22',color:col,border:`1px solid ${col}44`,display:'flex',alignItems:'center',justifyContent:'center',fontFamily:'var(--mono)',fontSize:11,fontWeight:600}}>{v.line}</div>
                <span style={{fontFamily:'var(--mono)',fontSize:13,fontWeight:500}}>{v.brigade}</span>
                <span style={{fontFamily:'var(--mono)',fontSize:10,color:'var(--text-dim)',marginLeft:'auto'}}>{v.id}</span>
              </div>
              <div style={{fontSize:11,color:'var(--text-dim)',marginBottom:4}}>→ {v.direction}</div>
              <div style={{display:'flex',gap:12,fontSize:11}}>
                <span style={{color:'var(--text-dim)'}}>Zajezdnia: <span style={{color:col,fontWeight:500}}>{v.depot}</span></span>
                <span style={{color:dc,fontFamily:'var(--mono)',fontWeight:600,marginLeft:'auto'}}>{delayLabel(v.delay)}</span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ── App ───────────────────────────────────────────────────
function App() {
  const [myLines, setMyLines] = useState(new Set(['75','74']));
  const [vehicles, setVehicles] = useState(VEHICLES_DATA);
  const [selectedLine, setSelectedLine] = useState(null);
  const [selectedVehicle, setSelectedVehicle] = useState(null);
  const [activeTab, setActiveTab] = useState('map');
  const [activeModal, setActiveModal] = useState(null);
  const [modalVehicle, setModalVehicle] = useState(null);
  const [rightPanelMode, setRightPanelMode] = useState(null); // null | 'vehicle' | 'punct'
  const [showAllRoutes, setShowAllRoutes] = useState(false);
  const [watchedLines, setWatchedLines] = useState(new Set());

  function toggleWatch(id) {
    setWatchedLines(s => {
      const n = new Set(s);
      if (n.has(id)) { n.delete(id); return n; }
      if (n.size >= 3) return s;
      n.add(id);
      return n;
    });
  }
  const [showLineControl, setShowLineControl] = useState(false);

  // Simulate live delay changes
  useEffect(() => {
    const id = setInterval(() => {
      setVehicles(vs => vs.map(v => ({
        ...v,
        delay: Math.max(-5, Math.min(20, v.delay + (Math.random() > 0.7 ? (Math.random()>0.5?1:-1) : 0))),
        speed: Math.max(0, Math.min(80, v.speed + (Math.random()-0.5)*4)),
      })));
    }, 4000);
    return () => clearInterval(id);
  }, []);

  function takeLine(id) { setMyLines(s => new Set([...s, id])); }
  function releaseLine(id) { setMyLines(s => { const n=new Set(s); n.delete(id); return n; }); }

  function openContact(v) { setModalVehicle(v); setActiveModal('contact'); }
  function openStops(v) { setModalVehicle(v); setActiveModal('stops'); }
  function openDetour(v) { setModalVehicle(v); setActiveModal('detour'); }

  function selectVehicle(v) {
    setSelectedVehicle(v);
    setRightPanelMode('vehicle');
    setSelectedLine(v.line);
  }

  const myVehicles = vehicles.filter(v=>myLines.has(v.line));
  const delayedCount = myVehicles.filter(v=>v.delay<-2).length;
  const onTimeCount  = myVehicles.filter(v=>v.delay>=-2&&v.delay<=1).length;
  const earlyCount   = myVehicles.filter(v=>v.delay>1).length;

  return (
    <div className="app">
      {/* HEADER */}
      <header className="app-header">
        <div className="logo">
          <div className="logo-dot"></div>
          FleetCore
        </div>
        <div className="header-sep"></div>
        <span className="header-city">Centrala Ruchu ZDiTM</span>
        <div className="header-sep"></div>
        <div className="header-tabs">
          {[['map','🗺 Mapa'],['punctuality','📊 Punktualność'],['brigades','🚌 Brygady']].map(([k,l])=>(
            <button key={k} className={`header-tab ${activeTab===k?'active':''}`} onClick={()=>setActiveTab(k)}>{l}</button>
          ))}
        </div>
        <div style={{marginLeft:'auto',display:'flex',alignItems:'center',gap:8}}>
          <button className="map-btn" onClick={()=>setShowLineControl(true)} style={{width:'auto',padding:'0 12px',fontSize:11,display:'flex',alignItems:'center',gap:6,height:28,borderRadius:6,border:'1px solid var(--border2)',background:'var(--surf2)',color:'var(--text)',cursor:'pointer'}}>
            <svg width="11" height="11" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/></svg>
            Kontrola Linii
            {myLines.size>0&&<span style={{fontFamily:'var(--mono)',fontSize:10,color:'var(--spak)',fontWeight:600}}>{myLines.size}</span>}
          </button>
          <button className="map-btn" onClick={()=>setActiveModal('login')} style={{width:'auto',padding:'0 10px',fontSize:11,display:'flex',alignItems:'center'}}>
            Logowanie Pojazdów
          </button>
          <div className="notif-btn" title={`${delayedCount} opóźnień`}>
            <svg width="13" height="13" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>
            {delayedCount>0 && <div className="notif-badge"></div>}
          </div>
          <Clock/>
          <div className="header-sep"></div>
          <div className="header-user" style={{flexShrink:0}}>
            <div className="header-avatar">MM</div>
            <span style={{fontSize:12,whiteSpace:'nowrap'}}>Michał Marszałek</span>
          </div>
        </div>
      </header>

      {/* SIDEBAR */}
      <Sidebar
        myLines={myLines} vehicles={vehicles}
        selectedLine={selectedLine}
        onSelectLine={id=>{setSelectedLine(s=>s===id?null:id); setRightPanelMode(null);}}
        watchedLines={watchedLines} onToggleWatch={toggleWatch}
      />

      {/* MAIN */}
      <div className="app-main">
        {activeTab === 'map' && (
          <>
            <div style={{flex:1,position:'relative',overflow:'hidden'}}>
            <MapView
              vehicles={vehicles} myLines={myLines}
              selectedLine={selectedLine} selectedVehicle={selectedVehicle}
              onSelectVehicle={selectVehicle}
              showAllRoutes={showAllRoutes}
            />
            {/* Map toolbar */}
            <div className="map-toolbar" style={{top:12,right:12,left:'auto'}}>
              <button className={`map-btn ${showAllRoutes?'active':''}`} title="Pokaż wszystkie trasy"
                onClick={()=>setShowAllRoutes(s=>!s)} style={{width:32,height:32,fontSize:10,padding:0}}>⊞</button>
              <button className="map-btn" title="Punktualność"
                onClick={()=>setRightPanelMode(m=>m==='punct'?null:'punct')} style={{fontSize:10}}>📊</button>
            </div>

            {/* Right panel */}
            {rightPanelMode==='punct' && (
              <PunctualityPanel myLines={myLines} vehicles={vehicles}
                onSelectVehicle={selectVehicle} onClose={()=>setRightPanelMode(null)}/>
            )}
            {rightPanelMode==='vehicle' && selectedVehicle && (
              <VehicleDetailPanel vehicle={selectedVehicle}
                onClose={()=>{setRightPanelMode(null);setSelectedVehicle(null);}}
                onContact={()=>openContact(selectedVehicle)}
                onStops={()=>openStops(selectedVehicle)}
                onDetour={()=>openDetour(selectedVehicle)}/>
            )}
            </div>

            {/* Diagram Ruchu overlay */}
            {watchedLines.size>0 && (
              <DiagramRuchu
                watchedLines={watchedLines}
                vehicles={vehicles}
                onClose={()=>setWatchedLines(new Set())}
              />
            )}

            {/* Status bar */}
            <div className="status-bar" style={{position:'relative',bottom:'auto',left:'auto',right:'auto'}}>              <div className="stat-item"><div className="stat-dot" style={{background:'var(--on-time)'}}></div>{onTimeCount} o czasie</div>
              <div className="stat-item"><div className="stat-dot" style={{background:'var(--delayed)'}}></div>{delayedCount} opóźnionych</div>
              <div className="stat-item"><div className="stat-dot" style={{background:'var(--early)'}}></div>{earlyCount} przyspieszone</div>
              <div style={{marginLeft:'auto',display:'flex',gap:12}}>
                <div className="stat-item">Moje linie: <strong style={{color:'var(--text)',marginLeft:3}}>{myLines.size}</strong></div>
                <div className="stat-item">Pojazdy: <strong style={{color:'var(--text)',marginLeft:3}}>{myVehicles.length}</strong></div>
              </div>
            </div>
          </>
        )}

        {activeTab === 'punctuality' && (
          <div style={{height:'100%',display:'flex',flexDirection:'column',overflow:'hidden'}}>
            <div style={{padding:'12px 16px',borderBottom:'1px solid var(--border)',display:'flex',alignItems:'center',gap:16}}>
              <div style={{fontSize:14,fontWeight:600}}>Punktualność pojazdów</div>
              <div style={{display:'flex',gap:8,marginLeft:'auto',fontFamily:'var(--mono)',fontSize:12}}>
                <span style={{color:'var(--on-time)'}}>{onTimeCount} o czasie</span>
                <span style={{color:'var(--delayed)'}}>{delayedCount} opóźnionych</span>
                <span style={{color:'var(--early)'}}>{earlyCount} przyspieszone</span>
              </div>
            </div>
            <div style={{flex:1,overflow:'auto',padding:16}}>
              <table style={{width:'100%',borderCollapse:'collapse',fontSize:12}}>
                <thead>
                  <tr style={{color:'var(--text-dim)',borderBottom:'1px solid var(--border)'}}>
                    {['Linia','Brygada','Pojazd','Kierunek','Zajezdnia','Prędkość','Opóźnienie'].map(h=>(
                      <th key={h} style={{textAlign:'left',padding:'6px 10px',fontSize:10,fontWeight:600,textTransform:'uppercase',letterSpacing:'0.06em'}}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {[...vehicles].filter(v=>myLines.has(v.line))
                    .sort((a,b)=>a.delay-b.delay)
                    .map(v=>{
                      const col = DEPOTS_DATA[v.depot].color;
                      const dc = delayColor(v.delay);
                      return (
                        <tr key={v.id} onClick={()=>{setActiveTab('map');selectVehicle(v);}}
                          style={{borderBottom:'1px solid var(--border)',cursor:'pointer',transition:'background 0.1s'}}
                          onMouseOver={e=>e.currentTarget.style.background='var(--surf2)'}
                          onMouseOut={e=>e.currentTarget.style.background='transparent'}>
                          <td style={{padding:'7px 10px'}}><div style={{display:'inline-flex',alignItems:'center',justifyContent:'center',width:28,height:18,borderRadius:3,background:col+'18',color:col,fontFamily:'var(--mono)',fontSize:10,fontWeight:600,border:`1px solid ${col}44`}}>{v.line}</div></td>
                          <td style={{padding:'7px 10px',fontFamily:'var(--mono)'}}>{v.brigade}</td>
                          <td style={{padding:'7px 10px',fontFamily:'var(--mono)',color:'var(--text-dim)'}}>{v.id}</td>
                          <td style={{padding:'7px 10px',color:'var(--text-dim)',maxWidth:140,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{v.direction}</td>
                          <td style={{padding:'7px 10px'}}><span style={{color:col,fontSize:11,fontWeight:500}}>{v.depot}</span></td>
                          <td style={{padding:'7px 10px',fontFamily:'var(--mono)',color:'var(--text-dim)'}}>{v.speed.toFixed(0)} km/h</td>
                          <td style={{padding:'7px 10px',fontFamily:'var(--mono)',fontWeight:600,color:dc}}>{delayLabel(v.delay)}</td>
                        </tr>
                      );
                    })}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeTab === 'brigades' && (
          <div style={{display:'flex',flexDirection:'column',height:'100%'}}>
            <div style={{padding:'12px 16px',borderBottom:'1px solid var(--border)',display:'flex',alignItems:'center',gap:12}}>
              <div style={{fontSize:14,fontWeight:600}}>Brygady i pojazdy</div>
              <button className="take-btn" style={{marginLeft:'auto'}} onClick={()=>setActiveModal('login')}>+ Zaloguj pojazd</button>
            </div>
            <BrigadesTab vehicles={vehicles} myLines={myLines}/>
          </div>
        )}
      </div>

      {/* MODALS */}
      {activeModal==='contact' && modalVehicle && (
        <ContactModal vehicle={modalVehicle} onClose={()=>setActiveModal(null)}/>
      )}
      {activeModal==='stops' && modalVehicle && (
        <StopsModal vehicle={modalVehicle} onClose={()=>setActiveModal(null)}/>
      )}
      {activeModal==='detour' && (
        <DetourModal vehicle={modalVehicle} onClose={()=>setActiveModal(null)}/>
      )}
      {activeModal==='login' && (
        <VehicleLoginModal onClose={()=>setActiveModal(null)}/>
      )}
      {showLineControl && (
        <LineControlModal
          myLines={myLines} dispatchers={DISPATCHERS_DATA}
          onTake={takeLine} onRelease={releaseLine}
          onClose={()=>setShowLineControl(false)}/>
      )}
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App/>);
